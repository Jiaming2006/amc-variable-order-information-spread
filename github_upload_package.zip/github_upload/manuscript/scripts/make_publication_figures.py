"""Create publication-style figures for the manuscript.

The script redraws all figures from the reproducible CSV outputs instead of
reusing exploratory PNG files. The style is intentionally restrained: Times New
Roman, vector PDF output, color-blind friendly colors, thin axes, and panel
labels suitable for Elsevier-style mathematical journals.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
import networkx as nx
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data" / "synthetic"
TABLES = ROOT / "outputs" / "tables"
OUT = ROOT / "manuscript" / "figures"

PALETTE = {
    "blue": "#2B6CB0",
    "orange": "#D55E00",
    "green": "#009E73",
    "purple": "#7B3294",
    "rose": "#CC6677",
    "gold": "#B58900",
    "gray": "#666666",
    "black": "#111111",
}


def configure_style() -> None:
    mpl.rcParams.update(
        {
            "font.family": "Times New Roman",
            "font.size": 8.5,
            "axes.labelsize": 9.0,
            "axes.titlesize": 9.0,
            "xtick.labelsize": 8.0,
            "ytick.labelsize": 8.0,
            "legend.fontsize": 7.6,
            "axes.linewidth": 0.65,
            "xtick.major.width": 0.6,
            "ytick.major.width": 0.6,
            "xtick.major.size": 3.0,
            "ytick.major.size": 3.0,
            "lines.linewidth": 1.55,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "mathtext.fontset": "stix",
            "savefig.dpi": 600,
            "savefig.bbox": "tight",
        }
    )


def clean_axes(ax: plt.Axes) -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.tick_params(direction="out", length=3.0, width=0.6)
    ax.grid(True, axis="y", color="#E8E8E8", linewidth=0.45)


def panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(
        -0.13,
        1.08,
        label,
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=11.5,
        fontweight="bold",
    )


def save(fig: plt.Figure, name: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f"{name}.pdf")
    fig.savefig(OUT / f"{name}.png", dpi=600)
    plt.close(fig)


def load_edges(name: str) -> nx.Graph:
    edges = pd.read_csv(DATA / f"edges_{name}.csv")
    graph = nx.Graph()
    graph.add_nodes_from(range(120))
    graph.add_weighted_edges_from(
        (int(row.source), int(row.target), float(row.weight))
        for row in edges.itertuples(index=False)
    )
    return graph


def draw_layer(ax: plt.Axes, graph: nx.Graph, pos: dict[int, np.ndarray], color: str, title: str) -> None:
    degrees = dict(graph.degree())
    node_sizes = [8.0 + 1.8 * np.sqrt(degrees.get(node, 0.0)) for node in graph.nodes()]
    nx.draw_networkx_edges(graph, pos, ax=ax, edge_color="#BDBDBD", width=0.32, alpha=0.34)
    nx.draw_networkx_nodes(
        graph,
        pos,
        ax=ax,
        node_size=node_sizes,
        node_color=color,
        alpha=0.88,
        linewidths=0.0,
    )
    ax.set_title(title, pad=2.5)
    ax.set_axis_off()


def draw_model_schematic(ax: plt.Axes) -> None:
    ax.set_axis_off()
    boxes = {
        "S": (0.07, 0.58),
        "I": (0.40, 0.58),
        "R": (0.73, 0.58),
        "B": (0.40, 0.18),
    }
    for text, (x, y) in boxes.items():
        patch = FancyBboxPatch(
            (x, y),
            0.18,
            0.16,
            boxstyle="round,pad=0.0,rounding_size=0.018",
            linewidth=0.8,
            edgecolor="#222222",
            facecolor="#F6F6F6",
            transform=ax.transAxes,
        )
        ax.add_patch(patch)
        ax.text(x + 0.09, y + 0.08, text, transform=ax.transAxes, ha="center", va="center", fontsize=11.0)

    def arrow(
        start: tuple[float, float],
        end: tuple[float, float],
        text: str,
        rad: float = 0.0,
        text_xy: tuple[float, float] | None = None,
    ) -> None:
        arr = FancyArrowPatch(
            start,
            end,
            connectionstyle=f"arc3,rad={rad}",
            arrowstyle="-|>",
            mutation_scale=9,
            linewidth=0.8,
            color="#222222",
            shrinkA=1.5,
            shrinkB=1.5,
            transform=ax.transAxes,
        )
        ax.add_patch(arr)
        if text_xy is None:
            text_xy = ((start[0] + end[0]) / 2, (start[1] + end[1]) / 2 + 0.045)
        ax.text(
            *text_xy,
            text,
            transform=ax.transAxes,
            ha="center",
            va="center",
            fontsize=8.0,
            bbox={"facecolor": "white", "edgecolor": "none", "pad": 0.6},
        )

    arrow((0.265, 0.66), (0.385, 0.66), r"$\lambda_i(t)$", text_xy=(0.325, 0.725))
    arrow((0.595, 0.66), (0.715, 0.66), r"$\gamma$", text_xy=(0.655, 0.725))
    arrow((0.82, 0.77), (0.16, 0.77), r"$\xi$", rad=0.28, text_xy=(0.49, 0.92))
    arrow((0.505, 0.565), (0.505, 0.355), r"$\eta I_i+\mu P_i$", text_xy=(0.66, 0.46))
    arrow((0.455, 0.355), (0.455, 0.565), r"$\kappa B_i$", rad=-0.25, text_xy=(0.30, 0.46))
    ax.text(
        0.06,
        0.08,
        r"$\alpha(t)=\alpha_{\max}-(\alpha_{\max}-\alpha_{\min})$",
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=8.0,
    )
    ax.text(
        0.06,
        0.02,
        r"$\times\,\bar B(t)/(\bar B(t)+h_\alpha)$",
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=8.0,
    )


def figure_model_network() -> None:
    graphs = {name: load_edges(name) for name in ["online", "offline", "media"]}
    aggregate = nx.Graph()
    aggregate.add_nodes_from(range(120))
    for graph in graphs.values():
        aggregate.add_edges_from(graph.edges())
    pos = nx.spring_layout(aggregate, seed=20260601, k=0.32, iterations=80)

    fig, axes = plt.subplots(2, 2, figsize=(7.1, 5.5), constrained_layout=True)
    draw_layer(axes[0, 0], graphs["online"], pos, PALETTE["blue"], "Online scale-free layer")
    draw_layer(axes[0, 1], graphs["offline"], pos, PALETTE["green"], "Offline small-world layer")
    draw_layer(axes[1, 0], graphs["media"], pos, PALETTE["orange"], "Media broadcast layer")
    draw_model_schematic(axes[1, 1])
    axes[1, 1].set_title("Node-level memory-feedback mechanism", pad=2.5)
    for ax, lab in zip(axes.flat, ["A", "B", "C", "D"], strict=True):
        panel_label(ax, lab)
    save(fig, "fig1_model_network")


def line_panel(
    ax: plt.Axes,
    timeseries: pd.DataFrame,
    group: str,
    order: list[str],
    labels: dict[str, str],
    colors: list[str],
    ycol: str = "I_mean",
    ylabel: str = "Mean spreader fraction",
) -> None:
    subset = timeseries[timeseries["scenario_group"] == group]
    for scenario, color in zip(order, colors, strict=True):
        frame = subset[subset["scenario"] == scenario]
        ax.plot(frame["t"], frame[ycol], color=color, label=labels.get(scenario, scenario))
    ax.set_xlabel("Time")
    ax.set_ylabel(ylabel)
    clean_axes(ax)


def figure_threshold_convergence() -> None:
    ts = pd.read_csv(TABLES / "mean_timeseries.csv")
    metrics = pd.read_csv(TABLES / "experiment_metrics.csv")
    conv = pd.read_csv(TABLES / "convergence_table.csv")

    fig, axes = plt.subplots(1, 3, figsize=(7.1, 2.35), constrained_layout=True)
    line_panel(
        axes[0],
        ts,
        "threshold",
        ["subcritical_R0_0.70", "supercritical_R0_1.35"],
        {"subcritical_R0_0.70": r"$\mathcal{R}_0=0.70$", "supercritical_R0_1.35": r"$\mathcal{R}_0=1.35$"},
        [PALETTE["blue"], PALETTE["orange"]],
    )
    axes[0].legend(frameon=False, loc="upper left")

    subset = metrics[metrics["scenario_group"] == "threshold"].copy()
    axes[1].bar(
        [0, 1],
        subset["final_I"],
        color=[PALETTE["blue"], PALETTE["orange"]],
        width=0.62,
        edgecolor="#222222",
        linewidth=0.45,
    )
    axes[1].set_xticks([0, 1], [r"0.70", r"1.35"])
    axes[1].set_xlabel(r"$\mathcal{R}_0$")
    axes[1].set_ylabel("Final spreader fraction")
    clean_axes(axes[1])

    axes[2].loglog(conv["dt"], conv["rms_error_I"], marker="o", color=PALETTE["purple"], markersize=4.2)
    for row in conv.itertuples(index=False):
        axes[2].annotate(f"{row.rms_error_I:.1e}", (row.dt, row.rms_error_I), textcoords="offset points", xytext=(2, 4), fontsize=6.8)
    axes[2].invert_xaxis()
    axes[2].set_xlabel("Time step")
    axes[2].set_ylabel("RMS error in mean I")
    clean_axes(axes[2])

    for ax, lab in zip(axes, ["A", "B", "C"], strict=True):
        panel_label(ax, lab)
    save(fig, "fig2_threshold_convergence")


def figure_variable_order() -> None:
    ts = pd.read_csv(TABLES / "mean_timeseries.csv")
    order = [
        "constant_alpha_0.72",
        "constant_alpha_0.86",
        "constant_alpha_0.94",
        "variable_alpha_feedback",
    ]
    labels = {
        "constant_alpha_0.72": r"$\alpha=0.72$",
        "constant_alpha_0.86": r"$\alpha=0.86$",
        "constant_alpha_0.94": r"$\alpha=0.94$",
        "variable_alpha_feedback": r"feedback-driven $\alpha(t)$",
    }
    colors = [PALETTE["blue"], PALETTE["green"], PALETTE["orange"], PALETTE["purple"]]

    fig, axes = plt.subplots(1, 2, figsize=(7.1, 2.95), constrained_layout=True)
    line_panel(axes[0], ts, "variable_order", order, labels, colors)
    handles, legend_labels = axes[0].get_legend_handles_labels()
    line_panel(
        axes[1],
        ts,
        "variable_order",
        order,
        labels,
        colors,
        ycol="alpha",
        ylabel=r"Fractional order $\alpha(t)$",
    )
    axes[1].set_ylim(0.68, 0.97)
    fig.legend(
        handles,
        legend_labels,
        frameon=False,
        loc="upper center",
        bbox_to_anchor=(0.53, 1.05),
        ncol=4,
        handlelength=1.8,
        columnspacing=0.9,
    )
    for ax, lab in zip(axes, ["A", "B"], strict=True):
        panel_label(ax, lab)
    save(fig, "fig3_variable_order")


def figure_feedback_intervention() -> None:
    ts = pd.read_csv(TABLES / "mean_timeseries.csv")
    metrics = pd.read_csv(TABLES / "experiment_metrics.csv")

    fig, axes = plt.subplots(1, 3, figsize=(7.1, 2.78), constrained_layout=True)
    line_panel(
        axes[0],
        ts,
        "feedback",
        ["feedback_0.0", "feedback_2.0", "feedback_5.0"],
        {"feedback_0.0": r"$\kappa=0$", "feedback_2.0": r"$\kappa=2$", "feedback_5.0": r"$\kappa=5$"},
        [PALETTE["orange"], PALETTE["green"], PALETTE["blue"]],
    )
    axes[0].legend(
        frameon=False,
        loc="upper center",
        bbox_to_anchor=(0.50, 1.26),
        ncol=3,
        handlelength=1.8,
        columnspacing=0.8,
    )

    intervention_order = [
        "no_control",
        "weak_clarification",
        "moderate_clarification",
        "strong_clarification",
    ]
    line_panel(
        axes[1],
        ts,
        "intervention",
        intervention_order,
        {
            "no_control": "none",
            "weak_clarification": "weak",
            "moderate_clarification": "moderate",
            "strong_clarification": "strong",
        },
        [PALETTE["orange"], PALETTE["gold"], PALETTE["green"], PALETTE["blue"]],
    )
    axes[1].legend(
        frameon=False,
        loc="upper center",
        bbox_to_anchor=(0.50, 1.26),
        ncol=2,
        handlelength=1.8,
        columnspacing=0.8,
    )

    im = metrics[metrics["scenario_group"] == "intervention"].set_index("scenario").loc[intervention_order]
    x = np.arange(len(intervention_order))
    axes[2].plot(x, im["R0"], marker="o", color=PALETTE["black"], label=r"$\mathcal{R}_c$")
    axes[2].axhline(1.0, color="#999999", linewidth=0.8, linestyle="--")
    ax2 = axes[2].twinx()
    ax2.bar(x, im["final_I"], color="#B8D7F0", edgecolor=PALETTE["blue"], linewidth=0.5, width=0.58, label="final I")
    axes[2].set_xticks(x, ["none", "weak", "moderate", "strong"], rotation=25, ha="right")
    axes[2].set_ylabel(r"$\mathcal{R}_c$")
    ax2.set_ylabel("Final spreader fraction")
    clean_axes(axes[2])
    ax2.spines["top"].set_visible(False)
    ax2.tick_params(direction="out", length=3.0, width=0.6)
    axes[2].grid(False)
    for ax, lab in zip(axes, ["A", "B", "C"], strict=True):
        panel_label(ax, lab)
    save(fig, "fig4_feedback_intervention")


def figure_network_robustness() -> None:
    ts = pd.read_csv(TABLES / "mean_timeseries.csv")
    metrics = pd.read_csv(TABLES / "experiment_metrics.csv")
    robust = pd.read_csv(TABLES / "robustness_summary.csv")

    fig, axes = plt.subplots(1, 3, figsize=(7.1, 2.82), constrained_layout=True)
    order = ["online_only", "media_only", "multilayer_baseline", "balanced_layers", "offline_only"]
    line_panel(
        axes[0],
        ts,
        "network_structure",
        order,
        {
            "online_only": "online",
            "media_only": "media",
            "multilayer_baseline": "baseline",
            "balanced_layers": "balanced",
            "offline_only": "offline",
        },
        [PALETTE["orange"], PALETTE["rose"], PALETTE["purple"], PALETTE["green"], PALETTE["blue"]],
    )
    axes[0].legend(
        frameon=False,
        loc="upper center",
        bbox_to_anchor=(0.50, 1.32),
        ncol=3,
        handlelength=1.8,
        columnspacing=0.8,
    )

    nm = metrics[metrics["scenario_group"] == "network_structure"].set_index("scenario").loc[order]
    x = np.arange(len(order))
    axes[1].bar(x, nm["spectral_radius"], color="#D8D8D8", edgecolor="#333333", linewidth=0.45, width=0.58)
    axes[1].set_xticks(x, ["online", "media", "base", "bal.", "offline"], rotation=25, ha="right")
    axes[1].set_ylabel(r"Spectral radius $\rho(QW)$")
    ax2 = axes[1].twinx()
    ax2.plot(x, nm["R0"], color=PALETTE["purple"], marker="o", markersize=3.5)
    ax2.set_ylabel(r"$\mathcal{R}_0$")
    clean_axes(axes[1])
    ax2.spines["top"].set_visible(False)
    ax2.tick_params(direction="out", length=3.0, width=0.6)
    axes[1].grid(False)

    labels = ["fb 0", "fb 5", "none", "strong", r"$\mathcal{R}_0<1$", r"$\mathcal{R}_0>1$"]
    colors = [PALETTE["orange"], PALETTE["blue"], PALETTE["orange"], PALETTE["blue"], PALETTE["green"], PALETTE["purple"]]
    y = robust["final_I_mean"].to_numpy()
    err = robust["final_I_std"].to_numpy()
    axes[2].bar(np.arange(len(y)), y, yerr=err, color=colors, alpha=0.86, edgecolor="#222222", linewidth=0.4, capsize=2.5)
    axes[2].set_xticks(np.arange(len(y)), labels, rotation=28, ha="right")
    axes[2].set_ylabel("Final spreader fraction")
    clean_axes(axes[2])

    for ax, lab in zip(axes, ["A", "B", "C"], strict=True):
        panel_label(ax, lab)
    save(fig, "fig5_network_robustness")


def main() -> None:
    configure_style()
    figure_model_network()
    figure_threshold_convergence()
    figure_variable_order()
    figure_feedback_intervention()
    figure_network_robustness()


if __name__ == "__main__":
    main()
