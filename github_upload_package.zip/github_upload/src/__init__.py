"""Numerical experiments for the AMC information-spread topic."""

