"""Build a synthetic multilayer information-spread dataset."""

from __future__ import annotations

import json
from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd

from model import ModelParams, params_to_json


ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data" / "synthetic"
SEED = 20260601
N_NODES = 120


def adjacency_from_graph(graph: nx.Graph, n_nodes: int) -> np.ndarray:
    nodes = list(range(n_nodes))
    return nx.to_numpy_array(graph, nodelist=nodes, dtype=float)


def write_edges(adjacency: np.ndarray, path: Path) -> pd.DataFrame:
    rows = []
    for i in range(adjacency.shape[0]):
        for j in range(i + 1, adjacency.shape[1]):
            if adjacency[i, j] > 0:
                rows.append({"source": i, "target": j, "weight": float(adjacency[i, j])})
    frame = pd.DataFrame(rows)
    frame.to_csv(path, index=False)
    return frame


def layer_stats(name: str, graph: nx.Graph, weight: float) -> dict[str, float | str]:
    degrees = np.array([degree for _, degree in graph.degree()], dtype=float)
    return {
        "layer": name,
        "weight": weight,
        "nodes": graph.number_of_nodes(),
        "edges": graph.number_of_edges(),
        "avg_degree": float(degrees.mean()),
        "max_degree": float(degrees.max()),
        "density": float(nx.density(graph)),
        "avg_clustering": float(nx.average_clustering(graph)),
    }


def build_synthetic_dataset(
    seed: int = SEED,
    n_nodes: int = N_NODES,
    susceptibility_sigma: float = 0.23,
    susceptibility_min: float = 0.58,
    susceptibility_max: float = 1.75,
) -> tuple[dict[str, nx.Graph], dict[str, np.ndarray], pd.DataFrame, pd.DataFrame, dict]:
    rng = np.random.default_rng(seed)

    online = nx.barabasi_albert_graph(n_nodes, 3, seed=seed)
    offline = nx.watts_strogatz_graph(n_nodes, 6, 0.08, seed=seed + 1)
    media = nx.erdos_renyi_graph(n_nodes, 0.035, seed=seed + 2)

    # Ensure isolated media-layer nodes receive at least a weak broadcast contact.
    media_hubs = rng.choice(n_nodes, size=5, replace=False)
    for node in range(n_nodes):
        if media.degree(node) == 0:
            hub = int(rng.choice(media_hubs))
            if hub != node:
                media.add_edge(node, hub)

    graphs = {"online": online, "offline": offline, "media": media}
    weights = {"online": 0.50, "offline": 0.30, "media": 0.20}
    adjacencies = {
        name: adjacency_from_graph(graph, n_nodes) for name, graph in graphs.items()
    }

    layer_rows = []
    for name, graph in graphs.items():
        layer_rows.append(layer_stats(name, graph, weights[name]))
    layer_frame = pd.DataFrame(layer_rows)

    combined_degree = sum(adjacencies.values()).sum(axis=1)
    seed_nodes = np.argsort(combined_degree)[-6:]
    communities = np.arange(n_nodes) % 4
    rng.shuffle(communities)

    i0 = np.full(n_nodes, 0.001, dtype=float)
    i0[seed_nodes] = 0.035
    r0 = np.zeros(n_nodes, dtype=float)
    b0 = 0.018 + 0.012 * rng.random(n_nodes)
    b0[seed_nodes] += 0.035
    s0 = 1.0 - i0 - r0
    susceptibility = np.clip(
        rng.lognormal(mean=0.0, sigma=susceptibility_sigma, size=n_nodes),
        susceptibility_min,
        susceptibility_max,
    )

    nodes = pd.DataFrame(
        {
            "node_id": np.arange(n_nodes),
            "community": communities,
            "susceptibility": susceptibility,
            "combined_degree": combined_degree,
            "is_initial_seed": np.isin(np.arange(n_nodes), seed_nodes).astype(int),
            "S0": s0,
            "I0": i0,
            "R0": r0,
            "B0": b0,
        }
    )

    metadata = {
        "name": "synthetic_multilayer_information_spread",
        "seed": seed,
        "n_nodes": n_nodes,
        "susceptibility_sigma": susceptibility_sigma,
        "susceptibility_min": susceptibility_min,
        "susceptibility_max": susceptibility_max,
        "layers": list(graphs),
        "layer_weights": weights,
        "initial_seed_nodes": [int(node) for node in seed_nodes],
        "description": (
            "Synthetic three-layer contact data for variable-order fractional "
            "multilayer information-spread experiments."
        ),
    }
    return graphs, adjacencies, nodes, layer_frame, metadata


def main() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    graphs, adjacencies, nodes, layer_frame, metadata = build_synthetic_dataset()

    for name in graphs:
        write_edges(adjacencies[name], DATA_DIR / f"edges_{name}.csv")
    layer_frame.to_csv(DATA_DIR / "layers.csv", index=False)
    nodes.to_csv(DATA_DIR / "nodes.csv", index=False)
    params_to_json(ModelParams(), DATA_DIR / "params_baseline.json")
    (DATA_DIR / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(f"Wrote dataset to {DATA_DIR}")
    print(layer_frame.to_string(index=False))


if __name__ == "__main__":
    main()
