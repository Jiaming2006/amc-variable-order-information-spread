"""Validate dataset, numerical outputs, and reproducibility diagnostics."""

from __future__ import annotations

import hashlib
from pathlib import Path
import sys

import numpy as np
import pandas as pd

from model import l1_history, simulate
from run_experiments import (
    DATA_DIR,
    DEFAULT_DT,
    DEFAULT_HORIZON,
    FIGURE_DIR,
    ROOT,
    TABLE_DIR,
    load_dataset,
    set_beta_for_target_r0,
)
from model import contact_matrix_from_layers, with_params


REPORT_PATH = ROOT / "outputs" / "validation_report.md"
MANIFEST_PATH = ROOT / "outputs" / "output_manifest.csv"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def check(rows: list[dict[str, str]], name: str, condition: bool, detail: str) -> None:
    rows.append(
        {
            "check": name,
            "status": "PASS" if condition else "FAIL",
            "detail": detail,
        }
    )


def ordered_values(metrics: pd.DataFrame, group: str, order: list[str], column: str) -> list[float]:
    subset = metrics[metrics["scenario_group"] == group].set_index("scenario")
    return [float(subset.loc[name, column]) for name in order]


def strictly_decreasing(values: list[float], tol: float = 0.0) -> bool:
    return all(values[i] > values[i + 1] + tol for i in range(len(values) - 1))


def write_manifest() -> pd.DataFrame:
    roots = [ROOT / "data", TABLE_DIR, FIGURE_DIR, ROOT / "outputs"]
    skip = {REPORT_PATH.resolve(), MANIFEST_PATH.resolve()}
    files: list[Path] = []
    for root in roots:
        if not root.exists():
            continue
        for path in root.rglob("*"):
            if path.is_file() and path.resolve() not in skip:
                files.append(path)
    rows = [
        {
            "path": str(path.relative_to(ROOT)),
            "bytes": path.stat().st_size,
            "sha256": sha256_file(path),
        }
        for path in sorted(set(files))
    ]
    manifest = pd.DataFrame(rows)
    manifest.to_csv(MANIFEST_PATH, index=False)
    return manifest


def main() -> int:
    rows: list[dict[str, str]] = []

    nodes = pd.read_csv(DATA_DIR / "nodes.csv")
    layers = pd.read_csv(DATA_DIR / "layers.csv")
    metrics = pd.read_csv(TABLE_DIR / "experiment_metrics.csv")
    scenarios = pd.read_csv(TABLE_DIR / "scenario_parameters.csv")
    preservation = pd.read_csv(TABLE_DIR / "preservation_diagnostics.csv")
    timeseries = pd.read_csv(TABLE_DIR / "mean_timeseries.csv")
    convergence = pd.read_csv(TABLE_DIR / "convergence_table.csv")
    robustness_summary = pd.read_csv(TABLE_DIR / "robustness_summary.csv")
    robustness_checks = pd.read_csv(TABLE_DIR / "robustness_checks.csv")
    scheme_comparison = pd.read_csv(TABLE_DIR / "scheme_comparison.csv")
    variable_distinctiveness = pd.read_csv(
        TABLE_DIR / "variable_order_distinctiveness.csv"
    )
    scaling_heterogeneity = pd.read_csv(TABLE_DIR / "scaling_heterogeneity.csv")

    required_node_cols = {
        "node_id",
        "community",
        "susceptibility",
        "combined_degree",
        "is_initial_seed",
        "S0",
        "I0",
        "R0",
        "B0",
    }
    check(
        rows,
        "node_table_schema",
        required_node_cols.issubset(nodes.columns),
        f"columns={len(nodes.columns)}, rows={len(nodes)}",
    )
    sir_sum = nodes[["S0", "I0", "R0"]].sum(axis=1)
    check(
        rows,
        "initial_mass",
        bool(np.allclose(sir_sum, 1.0, atol=1e-14)),
        f"max_error={float(np.max(np.abs(sir_sum - 1.0))):.3e}",
    )
    check(
        rows,
        "initial_bounds",
        bool(
            (nodes[["S0", "I0", "R0", "B0"]] >= 0.0).all().all()
            and (nodes["B0"] <= 1.0).all()
            and (nodes["susceptibility"] > 0.0).all()
        ),
        "initial states nonnegative, B0 <= 1, susceptibility > 0",
    )
    check(
        rows,
        "layer_table",
        bool(set(layers["layer"]) == {"online", "offline", "media"} and (layers["edges"] > 0).all()),
        layers[["layer", "edges", "avg_degree"]].to_dict(orient="records").__repr__(),
    )

    expected_groups = {
        "threshold": 2,
        "variable_order": 4,
        "feedback": 3,
        "network_structure": 5,
        "intervention": 4,
    }
    group_counts = metrics.groupby("scenario_group")["scenario"].nunique().to_dict()
    check(
        rows,
        "scenario_coverage",
        group_counts == expected_groups,
        f"groups={group_counts}",
    )
    expected_rows = int(sum(expected_groups.values()) * (DEFAULT_HORIZON / DEFAULT_DT + 1))
    check(
        rows,
        "timeseries_coverage",
        len(timeseries) == expected_rows,
        f"rows={len(timeseries)}, expected={expected_rows}",
    )
    check(
        rows,
        "scenario_parameter_table",
        len(scenarios) == len(metrics) and scenarios["R0"].notna().all(),
        f"rows={len(scenarios)}",
    )

    check(
        rows,
        "nonnegativity_preservation",
        bool(preservation["min_state"].min() >= -1e-12),
        f"min_state={preservation['min_state'].min():.3e}",
    )
    check(
        rows,
        "mass_preservation",
        bool(preservation["max_total_error"].max() < 1e-10),
        f"max_total_error={preservation['max_total_error'].max():.3e}",
    )
    check(
        rows,
        "mean_timeseries_bounds",
        bool(
            np.isfinite(timeseries[["S_mean", "I_mean", "R_mean", "B_mean", "alpha"]]).all().all()
            and (timeseries[["S_mean", "I_mean", "R_mean", "B_mean"]] >= -1e-12).all().all()
            and (timeseries["alpha"] >= 0.72 - 1e-12).all()
            and (timeseries["alpha"] <= 0.94 + 1e-12).all()
        ),
        "finite aggregate states, nonnegative means, alpha within prescribed bounds",
    )

    threshold_final = ordered_values(
        metrics,
        "threshold",
        ["subcritical_R0_0.70", "supercritical_R0_1.35"],
        "final_I",
    )
    threshold_r0 = ordered_values(
        metrics,
        "threshold",
        ["subcritical_R0_0.70", "supercritical_R0_1.35"],
        "R0",
    )
    check(
        rows,
        "threshold_response",
        bool(threshold_r0[0] < 1.0 < threshold_r0[1] and threshold_final[0] < threshold_final[1]),
        f"R0={threshold_r0}, final_I={threshold_final}",
    )

    feedback_order = ["feedback_0.0", "feedback_2.0", "feedback_5.0"]
    feedback_peak = ordered_values(metrics, "feedback", feedback_order, "peak_I")
    feedback_final = ordered_values(metrics, "feedback", feedback_order, "final_I")
    check(
        rows,
        "feedback_monotonicity",
        bool(strictly_decreasing(feedback_peak) and strictly_decreasing(feedback_final)),
        f"peak_I={feedback_peak}, final_I={feedback_final}",
    )

    intervention_order = [
        "no_control",
        "weak_clarification",
        "moderate_clarification",
        "strong_clarification",
    ]
    intervention_r0 = ordered_values(metrics, "intervention", intervention_order, "R0")
    intervention_peak = ordered_values(metrics, "intervention", intervention_order, "peak_I")
    intervention_final = ordered_values(metrics, "intervention", intervention_order, "final_I")
    check(
        rows,
        "intervention_monotonicity",
        bool(
            strictly_decreasing(intervention_r0)
            and strictly_decreasing(intervention_peak)
            and strictly_decreasing(intervention_final)
            and intervention_r0[-1] < 1.0
        ),
        f"R0={intervention_r0}, peak_I={intervention_peak}, final_I={intervention_final}",
    )

    errors = convergence["rms_error_I"].to_numpy(dtype=float)
    check(
        rows,
        "convergence_error_decrease",
        bool(all(errors[i] > errors[i + 1] for i in range(len(errors) - 1))),
        f"rms_error_I={errors.tolist()}",
    )
    check(
        rows,
        "robustness_seed_coverage",
        bool(
            robustness_summary["n_seeds"].min() >= 20
            and robustness_checks["seed"].nunique() >= 20
        ),
        f"n_seeds_min={int(robustness_summary['n_seeds'].min())}, checks={len(robustness_checks)}",
    )
    check(
        rows,
        "robustness_claims",
        bool(robustness_checks["passed"].all()),
        robustness_checks.groupby("check")["passed"].mean().to_dict().__repr__(),
    )

    constant_history = np.ones((5, 3, 4), dtype=float)
    history_term = l1_history(constant_history, 0.83)
    check(
        rows,
        "l1_history_constant_preservation",
        bool(np.allclose(history_term, 1.0, atol=1e-14)),
        f"max_error={float(np.max(np.abs(history_term - 1.0))):.3e}",
    )

    layers_dict, initial, susceptibility, base = load_dataset()
    weights = {"online": 0.50, "offline": 0.30, "media": 0.20}
    contact = contact_matrix_from_layers(layers_dict, weights)
    params = with_params(
        set_beta_for_target_r0(base, contact, susceptibility, 1.25),
        alpha_mode="variable",
    )
    run_a = simulate(initial, contact, susceptibility, params, horizon=4.0, dt=0.4)
    run_b = simulate(initial, contact, susceptibility, params, horizon=4.0, dt=0.4)
    check(
        rows,
        "deterministic_solver",
        bool(np.allclose(run_a["states"], run_b["states"], atol=0.0, rtol=0.0)),
        "same inputs produce bitwise-identical state arrays",
    )
    check(
        rows,
        "clip_free_bounds",
        bool(
            np.min(run_a["states"]) >= -1e-12
            and np.max(run_a["alphas"]) <= params.alpha_max + 1e-12
            and np.min(run_a["alphas"]) >= params.alpha_min - 1e-12
        ),
        (
            f"min_state={float(np.min(run_a['states'])):.3e}, "
            f"alpha_range=[{float(np.min(run_a['alphas'])):.5f}, {float(np.max(run_a['alphas'])):.5f}]"
        ),
    )
    nsfd_row = scheme_comparison.set_index("method").loc["L1-NSFD"]
    explicit_row = scheme_comparison.set_index("method").loc["standard_explicit_L1"]
    check(
        rows,
        "scheme_comparison",
        bool(
            nsfd_row["min_state"] >= -1e-12
            and int(nsfd_row["negative_entries"]) == 0
            and explicit_row["min_state"] < -1e-3
            and int(explicit_row["negative_entries"]) > 0
        ),
        (
            f"nsfd_min={nsfd_row['min_state']:.3e}, "
            f"explicit_min={explicit_row['min_state']:.3e}, "
            f"explicit_negative_entries={int(explicit_row['negative_entries'])}"
        ),
    )
    distinct_row = variable_distinctiveness.iloc[0]
    check(
        rows,
        "variable_order_distinctiveness",
        bool(
            distinct_row["variable_alpha_max"] - distinct_row["variable_alpha_min"] > 0.10
            and distinct_row["best_constant_rms_mismatch"] > 1e-3
            and distinct_row["best_constant_final_abs_mismatch"] > 1e-3
        ),
        (
            f"alpha_range=[{distinct_row['variable_alpha_min']:.5f}, "
            f"{distinct_row['variable_alpha_max']:.5f}], "
            f"best_alpha={distinct_row['best_constant_alpha']:.3f}, "
            f"rms={distinct_row['best_constant_rms_mismatch']:.3e}, "
            f"final_mismatch={distinct_row['best_constant_final_abs_mismatch']:.3e}"
        ),
    )
    check(
        rows,
        "scaling_heterogeneity",
        bool(
            (scaling_heterogeneity["n_nodes"] == 500).all()
            and scaling_heterogeneity["threshold_spectral_radius"].notna().all()
            and (
                abs(
                    scaling_heterogeneity["threshold_spectral_radius"]
                    - scaling_heterogeneity["contact_spectral_radius"]
                )
                > 0.01
            ).all()
            and (
                scaling_heterogeneity["supercritical_final_I"]
                > scaling_heterogeneity["subcritical_final_I"]
            ).all()
        ),
        scaling_heterogeneity[
            [
                "case",
                "threshold_spectral_radius",
                "contact_spectral_radius",
                "subcritical_final_I",
                "supercritical_final_I",
            ]
        ].to_dict(orient="records").__repr__(),
    )

    png_files = sorted(FIGURE_DIR.glob("*.png"))
    png_valid = True
    for path in png_files:
        png_valid = png_valid and path.read_bytes().startswith(b"\x89PNG\r\n\x1a\n")
    check(
        rows,
        "figure_outputs",
        bool(len(png_files) >= 7 and png_valid),
        f"png_count={len(png_files)}",
    )

    manifest = write_manifest()
    check(
        rows,
        "output_manifest",
        bool(len(manifest) >= 15 and (manifest["bytes"] > 0).all()),
        f"files={len(manifest)}",
    )

    report = pd.DataFrame(rows)
    failed = report[report["status"] != "PASS"]
    lines = [
        "# Validation report",
        "",
        report.to_markdown(index=False),
        "",
        "## Verdict",
        "",
        "PASS: all validation checks succeeded." if failed.empty else "FAIL: one or more validation checks failed.",
    ]
    REPORT_PATH.write_text("\n".join(lines) + "\n")
    print(report.to_string(index=False))
    print(f"Wrote validation report to {REPORT_PATH}")
    print(f"Wrote output manifest to {MANIFEST_PATH}")
    return 0 if failed.empty else 1


if __name__ == "__main__":
    sys.exit(main())
