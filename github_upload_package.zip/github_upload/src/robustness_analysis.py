"""Multi-seed robustness checks for the main numerical conclusions."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from build_dataset import build_synthetic_dataset
from model import contact_matrix_from_layers, simulate, summarize_run, with_params
from run_experiments import FIGURE_DIR, ROOT, TABLE_DIR, set_beta_for_target_r0
from model import ModelParams


ROBUST_SEEDS = [20260601 + 101 * i for i in range(20)]
BASELINE_WEIGHTS = {"online": 0.50, "offline": 0.30, "media": 0.20}
ROBUST_HORIZON = 35.0
ROBUST_DT = 0.25
ROBUST_NOTES_PATH = ROOT / "outputs" / "robustness_summary.md"


def run_case(
    rows: list[dict[str, float | str]],
    seed: int,
    layers: dict[str, np.ndarray],
    initial: np.ndarray,
    susceptibility: np.ndarray,
    params: ModelParams,
    claim: str,
    scenario: str,
) -> None:
    contact = contact_matrix_from_layers(layers, BASELINE_WEIGHTS)
    result = simulate(
        initial,
        contact,
        susceptibility,
        params,
        horizon=ROBUST_HORIZON,
        dt=ROBUST_DT,
    )
    row = summarize_run(result, claim, scenario, params)
    row.update({"seed": seed, "horizon": ROBUST_HORIZON, "dt": ROBUST_DT})
    rows.append(row)


def claim_checks(runs: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for seed, frame in runs.groupby("seed"):
        threshold = frame[frame["scenario_group"] == "threshold"].set_index("scenario")
        feedback = frame[frame["scenario_group"] == "feedback"].set_index("scenario")
        intervention = frame[frame["scenario_group"] == "intervention"].set_index("scenario")

        rows.append(
            {
                "seed": seed,
                "check": "threshold_final_I",
                "passed": bool(
                    threshold.loc["subcritical_R0_0.70", "R0"] < 1.0
                    and threshold.loc["supercritical_R0_1.35", "R0"] > 1.0
                    and threshold.loc["subcritical_R0_0.70", "final_I"]
                    < threshold.loc["supercritical_R0_1.35", "final_I"]
                ),
            }
        )
        rows.append(
            {
                "seed": seed,
                "check": "feedback_suppression",
                "passed": bool(
                    feedback.loc["feedback_5.0", "peak_I"]
                    < feedback.loc["feedback_0.0", "peak_I"]
                    and feedback.loc["feedback_5.0", "final_I"]
                    < feedback.loc["feedback_0.0", "final_I"]
                ),
            }
        )
        rows.append(
            {
                "seed": seed,
                "check": "strong_intervention",
                "passed": bool(
                    intervention.loc["strong_clarification", "R0"] < 1.0
                    and intervention.loc["strong_clarification", "final_I"]
                    < intervention.loc["no_control", "final_I"]
                ),
            }
        )
    return pd.DataFrame(rows)


def write_plot(runs: pd.DataFrame, path: Path) -> None:
    specs = [
        ("threshold", ["subcritical_R0_0.70", "supercritical_R0_1.35"], "final_I"),
        ("feedback", ["feedback_0.0", "feedback_5.0"], "peak_I"),
        ("intervention", ["no_control", "strong_clarification"], "final_I"),
    ]
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.8))
    for ax, (group, scenarios, metric) in zip(axes, specs):
        subset = runs[runs["scenario_group"] == group]
        data = [
            subset[subset["scenario"] == scenario][metric].to_numpy(dtype=float)
            for scenario in scenarios
        ]
        ax.boxplot(data, tick_labels=scenarios, showmeans=True)
        ax.set_title(group)
        ax.set_ylabel(metric)
        ax.tick_params(axis="x", labelrotation=25)
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)


def main() -> None:
    TABLE_DIR.mkdir(parents=True, exist_ok=True)
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, float | str]] = []

    for seed in ROBUST_SEEDS:
        _, layers, nodes, _, _ = build_synthetic_dataset(seed=seed)
        initial = nodes[["S0", "I0", "R0", "B0"]].to_numpy(dtype=float)
        susceptibility = nodes["susceptibility"].to_numpy(dtype=float)
        contact = contact_matrix_from_layers(layers, BASELINE_WEIGHTS)
        base = ModelParams()

        for scenario, target in [
            ("subcritical_R0_0.70", 0.70),
            ("supercritical_R0_1.35", 1.35),
        ]:
            params = with_params(
                set_beta_for_target_r0(base, contact, susceptibility, target),
                alpha_mode="variable",
                feedback_strength=3.0,
            )
            run_case(rows, seed, layers, initial, susceptibility, params, "threshold", scenario)

        feedback_base = set_beta_for_target_r0(base, contact, susceptibility, 1.55)
        for feedback in [0.0, 5.0]:
            params = with_params(
                feedback_base,
                alpha_mode="variable",
                feedback_strength=feedback,
            )
            run_case(
                rows,
                seed,
                layers,
                initial,
                susceptibility,
                params,
                "feedback",
                f"feedback_{feedback:.1f}",
            )

        control_base = set_beta_for_target_r0(base, contact, susceptibility, 1.70)
        for scenario, recovery, reduction in [
            ("no_control", 0.00, 0.00),
            ("strong_clarification", 0.14, 0.35),
        ]:
            params = with_params(
                control_base,
                alpha_mode="variable",
                feedback_strength=3.0,
                intervention_recovery=recovery,
                contact_reduction=reduction,
            )
            run_case(rows, seed, layers, initial, susceptibility, params, "intervention", scenario)

    runs = pd.DataFrame(rows)
    summary = (
        runs.groupby(["scenario_group", "scenario"])
        .agg(
            n_seeds=("seed", "nunique"),
            R0_mean=("R0", "mean"),
            R0_std=("R0", "std"),
            peak_I_mean=("peak_I", "mean"),
            peak_I_std=("peak_I", "std"),
            final_I_mean=("final_I", "mean"),
            final_I_std=("final_I", "std"),
            final_I_min=("final_I", "min"),
            final_I_max=("final_I", "max"),
        )
        .reset_index()
    )
    checks = claim_checks(runs)
    pass_rates = checks.groupby("check")["passed"].mean().reset_index()

    runs.to_csv(TABLE_DIR / "robustness_runs.csv", index=False)
    summary.to_csv(TABLE_DIR / "robustness_summary.csv", index=False)
    checks.to_csv(TABLE_DIR / "robustness_checks.csv", index=False)
    write_plot(runs, FIGURE_DIR / "robustness_key_claims.png")
    ROBUST_NOTES_PATH.write_text(
        "\n".join(
            [
                "# Robustness summary",
                "",
                f"Repeated the key numerical claims over {len(ROBUST_SEEDS)} synthetic multilayer-network seeds.",
                "",
                "## Aggregate results",
                "",
                summary.to_markdown(index=False, floatfmt=".6f"),
                "",
                "## Claim pass rates",
                "",
                pass_rates.to_markdown(index=False, floatfmt=".3f"),
            ]
        )
        + "\n"
    )

    print(f"Wrote robustness runs to {TABLE_DIR / 'robustness_runs.csv'}")
    print(f"Wrote robustness summary to {TABLE_DIR / 'robustness_summary.csv'}")
    print(f"Wrote robustness checks to {TABLE_DIR / 'robustness_checks.csv'}")
    print(f"Wrote robustness figure to {FIGURE_DIR / 'robustness_key_claims.png'}")
    print(f"Wrote robustness notes to {ROBUST_NOTES_PATH}")
    print(summary.to_string(index=False))
    print(pass_rates.to_string(index=False))


if __name__ == "__main__":
    main()
