"""Run numerical experiments for the variable-order multilayer model."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from build_dataset import build_synthetic_dataset
from model import (
    ModelParams,
    contact_matrix_from_layers,
    mean_timeseries_frame,
    params_from_json,
    simulate,
    simulate_explicit_l1,
    spectral_radius,
    summarize_run,
    threshold_matrix,
    with_params,
)


ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data" / "synthetic"
TABLE_DIR = ROOT / "outputs" / "tables"
FIGURE_DIR = ROOT / "outputs" / "figures"
SUMMARY_PATH = ROOT / "outputs" / "results_summary.md"
CHINESE_NOTES_PATH = ROOT / "outputs" / "numerical_experiments_zh.md"
DEFAULT_HORIZON = 50.0
DEFAULT_DT = 0.2


def load_adjacency(edge_path: Path, n_nodes: int) -> np.ndarray:
    adjacency = np.zeros((n_nodes, n_nodes), dtype=float)
    edges = pd.read_csv(edge_path)
    for row in edges.itertuples(index=False):
        i = int(row.source)
        j = int(row.target)
        w = float(row.weight)
        adjacency[i, j] = w
        adjacency[j, i] = w
    return adjacency


def load_dataset() -> tuple[dict[str, np.ndarray], np.ndarray, np.ndarray, ModelParams]:
    nodes = pd.read_csv(DATA_DIR / "nodes.csv")
    layers = {}
    for name in ["online", "offline", "media"]:
        layers[name] = load_adjacency(DATA_DIR / f"edges_{name}.csv", len(nodes))
    initial = nodes[["S0", "I0", "R0", "B0"]].to_numpy(dtype=float)
    susceptibility = nodes["susceptibility"].to_numpy(dtype=float)
    params = params_from_json(DATA_DIR / "params_baseline.json")
    return layers, initial, susceptibility, params


def set_beta_for_target_r0(
    params: ModelParams,
    contact: np.ndarray,
    susceptibility: np.ndarray,
    target_r0: float,
) -> ModelParams:
    rho = spectral_radius(threshold_matrix(contact, susceptibility))
    gamma_eff = params.gamma + params.intervention_recovery
    beta = target_r0 * gamma_eff / rho / (1.0 - params.contact_reduction)
    return with_params(params, beta=beta)


def append_run(
    metrics: list[dict[str, float | str]],
    frames: list[pd.DataFrame],
    layers: dict[str, np.ndarray],
    weights: dict[str, float],
    initial: np.ndarray,
    susceptibility: np.ndarray,
    params: ModelParams,
    scenario_group: str,
    scenario: str,
    horizon: float = DEFAULT_HORIZON,
    dt: float = DEFAULT_DT,
) -> dict[str, np.ndarray | float]:
    contact = contact_matrix_from_layers(layers, weights)
    result = simulate(initial, contact, susceptibility, params, horizon=horizon, dt=dt)
    summary = summarize_run(result, scenario_group, scenario, params)
    summary.update(
        {
            "horizon": horizon,
            "dt": dt,
            "spectral_radius": spectral_radius(threshold_matrix(contact, susceptibility)),
            "contact_spectral_radius": spectral_radius(contact),
            "weight_online": float(weights.get("online", 0.0)),
            "weight_offline": float(weights.get("offline", 0.0)),
            "weight_media": float(weights.get("media", 0.0)),
        }
    )
    metrics.append(summary)
    frames.append(pd.DataFrame(mean_timeseries_frame(result, scenario_group, scenario)))
    return result


def plot_group(timeseries: pd.DataFrame, group: str, path: Path, ylabel: str = "Mean I") -> None:
    subset = timeseries[timeseries["scenario_group"] == group]
    plt.figure(figsize=(8.2, 4.8))
    for scenario, frame in subset.groupby("scenario"):
        plt.plot(frame["t"], frame["I_mean"], linewidth=2.0, label=scenario)
    plt.xlabel("t")
    plt.ylabel(ylabel)
    plt.legend(frameon=False, fontsize=8)
    plt.tight_layout()
    plt.savefig(path, dpi=220)
    plt.close()


def plot_alpha(timeseries: pd.DataFrame, path: Path) -> None:
    subset = timeseries[timeseries["scenario_group"] == "variable_order"]
    plt.figure(figsize=(8.2, 4.8))
    for scenario, frame in subset.groupby("scenario"):
        plt.plot(frame["t"], frame["alpha"], linewidth=2.0, label=scenario)
    plt.xlabel("t")
    plt.ylabel("Fractional order alpha(t)")
    plt.ylim(0.68, 0.97)
    plt.legend(frameon=False, fontsize=8)
    plt.tight_layout()
    plt.savefig(path, dpi=220)
    plt.close()


def convergence_experiment(
    layers: dict[str, np.ndarray],
    initial: np.ndarray,
    susceptibility: np.ndarray,
    base: ModelParams,
    weights: dict[str, float],
) -> pd.DataFrame:
    contact = contact_matrix_from_layers(layers, weights)
    params = set_beta_for_target_r0(base, contact, susceptibility, 1.30)
    params = with_params(params, feedback_strength=3.0, alpha_mode="variable")
    horizon = 16.0
    reference = simulate(initial, contact, susceptibility, params, horizon=horizon, dt=0.0125)
    ref_t = np.asarray(reference["times"], dtype=float)
    ref_i = np.asarray(reference["mean"], dtype=float)[:, 1]

    rows = []
    previous_error = None
    for dt in [0.4, 0.2, 0.1, 0.05, 0.025]:
        result = simulate(initial, contact, susceptibility, params, horizon=horizon, dt=dt)
        t = np.asarray(result["times"], dtype=float)
        i = np.asarray(result["mean"], dtype=float)[:, 1]
        ref_interp = np.interp(t, ref_t, ref_i)
        error = float(np.sqrt(np.mean((i - ref_interp) ** 2)))
        if previous_error is None:
            order = np.nan
        else:
            order = float(np.log(previous_error / error) / np.log(2.0))
        rows.append({"dt": dt, "rms_error_I": error, "estimated_order": order})
        previous_error = error
    return pd.DataFrame(rows)


def variable_order_distinctiveness_experiment(
    layers: dict[str, np.ndarray],
    initial: np.ndarray,
    susceptibility: np.ndarray,
    base: ModelParams,
    weights: dict[str, float],
) -> pd.DataFrame:
    contact = contact_matrix_from_layers(layers, weights)
    initial_stress = initial.copy()
    initial_stress[:, 3] = 0.02
    params = set_beta_for_target_r0(base, contact, susceptibility, 1.90)
    variable_params = with_params(
        params,
        alpha_mode="variable",
        feedback_strength=0.0,
        awareness_gain=0.80,
        awareness_network_gain=0.15,
        awareness_decay=0.18,
        alpha_half=0.08,
    )
    horizon = 40.0
    dt = 0.25
    variable_result = simulate(
        initial_stress,
        contact,
        susceptibility,
        variable_params,
        horizon=horizon,
        dt=dt,
    )
    times = np.asarray(variable_result["times"], dtype=float)
    variable_i = np.asarray(variable_result["mean"], dtype=float)[:, 1]
    variable_alpha = np.asarray(variable_result["alphas"], dtype=float)

    candidates = []
    for alpha in np.linspace(0.72, 0.94, 23):
        constant_params = with_params(
            variable_params,
            alpha_mode="constant",
            alpha_constant=float(alpha),
        )
        constant_result = simulate(
            initial_stress,
            contact,
            susceptibility,
            constant_params,
            horizon=horizon,
            dt=dt,
        )
        constant_i = np.asarray(constant_result["mean"], dtype=float)[:, 1]
        candidates.append(
            {
                "constant_alpha": float(alpha),
                "rms_mismatch": float(np.sqrt(np.mean((variable_i - constant_i) ** 2))),
                "peak_I": float(constant_i.max()),
                "peak_time": float(times[constant_i.argmax()]),
                "final_I": float(constant_i[-1]),
                "peak_abs_mismatch": float(abs(constant_i.max() - variable_i.max())),
                "peak_time_abs_mismatch": float(
                    abs(times[constant_i.argmax()] - times[variable_i.argmax()])
                ),
                "final_abs_mismatch": float(abs(constant_i[-1] - variable_i[-1])),
            }
        )
    candidate_frame = pd.DataFrame(candidates)
    best = candidate_frame.loc[candidate_frame["rms_mismatch"].idxmin()]
    peak_match = candidate_frame.loc[candidate_frame["peak_abs_mismatch"].idxmin()]
    final_match = candidate_frame.loc[candidate_frame["final_abs_mismatch"].idxmin()]

    return pd.DataFrame(
        [
            {
                "case": "variable_alpha_stress",
                "target_Rc": 1.90,
                "horizon": horizon,
                "dt": dt,
                "variable_alpha_min": float(variable_alpha.min()),
                "variable_alpha_max": float(variable_alpha.max()),
                "variable_alpha_mean": float(variable_alpha.mean()),
                "variable_alpha_final": float(variable_alpha[-1]),
                "variable_peak_I": float(variable_i.max()),
                "variable_peak_time": float(times[variable_i.argmax()]),
                "variable_final_I": float(variable_i[-1]),
                "best_constant_alpha": float(best["constant_alpha"]),
                "best_constant_rms_mismatch": float(best["rms_mismatch"]),
                "best_constant_relative_rms": float(
                    best["rms_mismatch"] / max(variable_i.max(), 1e-12)
                ),
                "best_constant_peak_I": float(best["peak_I"]),
                "best_constant_peak_time": float(best["peak_time"]),
                "best_constant_final_I": float(best["final_I"]),
                "best_constant_peak_abs_mismatch": float(best["peak_abs_mismatch"]),
                "best_constant_peak_time_abs_mismatch": float(
                    best["peak_time_abs_mismatch"]
                ),
                "best_constant_final_abs_mismatch": float(best["final_abs_mismatch"]),
                "peak_matched_alpha": float(peak_match["constant_alpha"]),
                "peak_matched_rms_mismatch": float(peak_match["rms_mismatch"]),
                "peak_matched_peak_abs_mismatch": float(
                    peak_match["peak_abs_mismatch"]
                ),
                "peak_matched_peak_time_abs_mismatch": float(
                    peak_match["peak_time_abs_mismatch"]
                ),
                "peak_matched_final_abs_mismatch": float(
                    peak_match["final_abs_mismatch"]
                ),
                "final_matched_alpha": float(final_match["constant_alpha"]),
                "final_matched_rms_mismatch": float(final_match["rms_mismatch"]),
                "final_matched_peak_abs_mismatch": float(
                    final_match["peak_abs_mismatch"]
                ),
                "final_matched_peak_time_abs_mismatch": float(
                    final_match["peak_time_abs_mismatch"]
                ),
                "final_matched_final_abs_mismatch": float(
                    final_match["final_abs_mismatch"]
                ),
            }
        ]
    )


def scheme_comparison_experiment(
    layers: dict[str, np.ndarray],
    initial: np.ndarray,
    susceptibility: np.ndarray,
    base: ModelParams,
    weights: dict[str, float],
) -> pd.DataFrame:
    contact = contact_matrix_from_layers(layers, weights)
    params = set_beta_for_target_r0(base, contact, susceptibility, 3.0)
    params = with_params(
        params,
        alpha_mode="variable",
        feedback_strength=0.0,
        saturation=0.0,
    )
    horizon = 20.0
    dt = 4.0

    rows = []
    for method, runner in [
        ("L1-NSFD", simulate),
        ("standard_explicit_L1", simulate_explicit_l1),
    ]:
        result = runner(initial, contact, susceptibility, params, horizon=horizon, dt=dt)
        mean_i = np.asarray(result["mean"], dtype=float)[:, 1]
        states = np.asarray(result["states"], dtype=float)
        rows.append(
            {
                "method": method,
                "target_Rc": 3.0,
                "dt": dt,
                "horizon": horizon,
                "min_state": float(result["min_state"]),
                "negative_entries": int(np.sum(states < -1e-12)),
                "max_total_error": float(result["max_total_error"]),
                "peak_I": float(mean_i.max()),
                "final_I": float(mean_i[-1]),
            }
        )
    return pd.DataFrame(rows)


def scaling_heterogeneity_experiment(base: ModelParams) -> pd.DataFrame:
    rows = []
    weights = {"online": 0.50, "offline": 0.30, "media": 0.20}
    for label, sigma, susceptibility_min, susceptibility_max in [
        ("N500_baseline_heterogeneity", 0.23, 0.58, 1.75),
        ("N500_strong_heterogeneity", 0.60, 0.35, 3.00),
    ]:
        _, layers, nodes, _, _ = build_synthetic_dataset(
            seed=20260601 + 500,
            n_nodes=500,
            susceptibility_sigma=sigma,
            susceptibility_min=susceptibility_min,
            susceptibility_max=susceptibility_max,
        )
        initial = nodes[["S0", "I0", "R0", "B0"]].to_numpy(dtype=float)
        susceptibility = nodes["susceptibility"].to_numpy(dtype=float)
        contact = contact_matrix_from_layers(layers, weights)
        rho_w = spectral_radius(contact)
        rho_qw = spectral_radius(threshold_matrix(contact, susceptibility))
        beta_critical = base.gamma / rho_qw
        final_values = {}
        for scenario, target in [("subcritical", 0.70), ("supercritical", 1.35)]:
            params = with_params(
                set_beta_for_target_r0(base, contact, susceptibility, target),
                alpha_mode="variable",
                feedback_strength=3.0,
            )
            result = simulate(initial, contact, susceptibility, params, horizon=25.0, dt=0.5)
            mean_i = np.asarray(result["mean"], dtype=float)[:, 1]
            final_values[f"{scenario}_final_I"] = float(mean_i[-1])
        rows.append(
            {
                "case": label,
                "n_nodes": 500,
                "susceptibility_sigma": sigma,
                "susceptibility_min": float(susceptibility.min()),
                "susceptibility_max": float(susceptibility.max()),
                "contact_spectral_radius": rho_w,
                "threshold_spectral_radius": rho_qw,
                "rho_qw_over_rho_w": rho_qw / rho_w,
                "critical_beta": beta_critical,
                **final_values,
            }
        )
    return pd.DataFrame(rows)


def write_summary(
    metrics: pd.DataFrame,
    convergence: pd.DataFrame,
    scheme_comparison: pd.DataFrame,
    variable_distinctiveness: pd.DataFrame,
    scaling_heterogeneity: pd.DataFrame,
) -> None:
    key = metrics.sort_values(["scenario_group", "scenario"]).copy()
    threshold = key[key["scenario_group"] == "threshold"][["scenario", "R0", "peak_I", "final_I"]]
    intervention = key[key["scenario_group"] == "intervention"][
        ["scenario", "R0", "peak_I", "final_I"]
    ]
    feedback = key[key["scenario_group"] == "feedback"][
        ["scenario", "R0", "feedback_strength", "peak_I", "final_I"]
    ]
    network = key[key["scenario_group"] == "network_structure"][
        ["scenario", "spectral_radius", "R0", "peak_I", "final_I"]
    ]
    variable = key[key["scenario_group"] == "variable_order"][
        ["scenario", "R0", "peak_I", "peak_time", "final_alpha"]
    ]

    lines = [
        "# Numerical results summary",
        "",
        "## Dataset",
        "",
        "- Synthetic three-layer network: online scale-free, offline small-world, media random-broadcast.",
        "- Node-level initial state uses six high-degree seed nodes and heterogeneous susceptibility.",
        "",
        "## Threshold check",
        "",
        threshold.to_markdown(index=False, floatfmt=".5f"),
        "",
        "## Variable-order effect",
        "",
        variable.to_markdown(index=False, floatfmt=".5f"),
        "",
        "## Intervention comparison",
        "",
        intervention.to_markdown(index=False, floatfmt=".5f"),
        "",
        "## Behavioral feedback comparison",
        "",
        feedback.to_markdown(index=False, floatfmt=".5f"),
        "",
        "## Multilayer network comparison",
        "",
        network.to_markdown(index=False, floatfmt=".5f"),
        "",
        "## Convergence estimate",
        "",
        convergence.to_markdown(index=False, floatfmt=".6f"),
        "",
        "## Scheme comparison",
        "",
        scheme_comparison.to_markdown(index=False, floatfmt=".6f"),
        "",
        "## Variable-order distinctiveness",
        "",
        variable_distinctiveness.to_markdown(index=False, floatfmt=".6f"),
        "",
        "## N=500 scaling and susceptibility heterogeneity",
        "",
        scaling_heterogeneity.to_markdown(index=False, floatfmt=".6f"),
        "",
        "## Numerical preservation diagnostics",
        "",
        f"- Minimum state over all runs: {metrics['min_state'].min():.3e}.",
        f"- Maximum node-wise |S+I+R-1| over all runs: {metrics['max_total_error'].max():.3e}.",
    ]
    SUMMARY_PATH.write_text("\n".join(lines) + "\n")


def write_chinese_notes(
    metrics: pd.DataFrame,
    convergence: pd.DataFrame,
    scheme_comparison: pd.DataFrame,
    variable_distinctiveness: pd.DataFrame,
    scaling_heterogeneity: pd.DataFrame,
) -> None:
    threshold = metrics[metrics["scenario_group"] == "threshold"][
        ["scenario", "R0", "peak_I", "final_I"]
    ]
    variable = metrics[metrics["scenario_group"] == "variable_order"][
        ["scenario", "peak_I", "peak_time", "final_alpha"]
    ]
    feedback = metrics[metrics["scenario_group"] == "feedback"][
        ["scenario", "feedback_strength", "peak_I", "final_I"]
    ]
    network = metrics[metrics["scenario_group"] == "network_structure"][
        ["scenario", "spectral_radius", "R0", "peak_I", "final_I"]
    ]
    intervention = metrics[metrics["scenario_group"] == "intervention"][
        ["scenario", "R0", "peak_I", "final_I"]
    ]

    lines = [
        "# 第 5 节数值实验说明草稿",
        "",
        "## 实验数据",
        "",
        "本文先构造一个可复现的三层合成网络数据集：线上社交层采用无标度网络，线下接触层采用小世界网络，媒体传播层采用随机广播网络。节点层面给出异质易感性、初始传播者种子、以及初始行为反馈强度。该设置对应论文引言和模型部分中的多层网络、记忆效应与行为反馈机制。",
        "",
        "## 数值格式可靠性",
        "",
        f"所有实验中状态变量最小值为 {metrics['min_state'].min():.3e}，节点层面的最大守恒误差 max |S+I+R-1| 为 {metrics['max_total_error'].max():.3e}。这说明当前 L1-NSFD 格式在计算上保持非负性和总量守恒，可用于支撑数值格式定理的实验验证。",
        "",
        "## 收敛性测试",
        "",
        convergence.to_markdown(index=False, floatfmt=".6f"),
        "",
        "误差随着步长减小而下降，说明格式在该算例上表现出稳定的网格收敛趋势。",
        "",
        "## 标准格式对照",
        "",
        scheme_comparison.to_markdown(index=False, floatfmt=".6f"),
        "",
        "在大步长压力测试中，显式 L1 对照格式出现负状态，而 L1-NSFD 仍保持非负性和节点质量守恒。",
        "",
        "## 变阶不可替代性诊断",
        "",
        variable_distinctiveness.to_markdown(index=False, floatfmt=".6f"),
        "",
        "在行为反馈快速改变记忆阶数的压力工况中，最佳常阶替代仍留下 RMS、峰时和终值误差，说明变阶项不是单纯的常阶插值记号。",
        "",
        "## N=500 与强异质性检查",
        "",
        scaling_heterogeneity.to_markdown(index=False, floatfmt=".6f"),
        "",
        "该诊断展示了更大网络和更强易感性异质性下 rho(QW) 与 rho(W) 的差别，并保留亚临界/超临界终值分离。",
        "",
        "## 阈值测试",
        "",
        threshold.to_markdown(index=False, floatfmt=".5f"),
        "",
        "当 R0 < 1 时，传播者比例最终接近零；当 R0 > 1 时，传播者比例维持在更高水平，符合阈值动力学预期。",
        "",
        "## 变阶函数影响",
        "",
        variable.to_markdown(index=False, floatfmt=".5f"),
        "",
        "较高的分数阶对应更快、更强的传播峰值；反馈诱导的变阶情形介于固定阶情形之间，体现记忆强度随行为状态变化的影响。",
        "",
        "## 行为反馈影响",
        "",
        feedback.to_markdown(index=False, floatfmt=".5f"),
        "",
        "反馈强度增大时，峰值传播比例和最终传播比例均下降，说明行为响应能够有效削弱传播压力。",
        "",
        "## 多层网络结构影响",
        "",
        network.to_markdown(index=False, floatfmt=".5f"),
        "",
        "不同层组合具有不同谱半径和传播阈值。线上层的无标度结构使传播更容易放大，线下层的小世界结构在本参数下传播较弱。",
        "",
        "## 干预策略比较",
        "",
        intervention.to_markdown(index=False, floatfmt=".5f"),
        "",
        "澄清强度和接触削减共同降低有效 R0；强干预将 R0 压低到 1 以下，并使最终传播比例接近零。",
    ]
    CHINESE_NOTES_PATH.write_text("\n".join(lines) + "\n")


def main() -> None:
    TABLE_DIR.mkdir(parents=True, exist_ok=True)
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    SUMMARY_PATH.parent.mkdir(parents=True, exist_ok=True)

    layers, initial, susceptibility, base = load_dataset()
    baseline_weights = {"online": 0.50, "offline": 0.30, "media": 0.20}
    baseline_contact = contact_matrix_from_layers(layers, baseline_weights)

    metrics: list[dict[str, float | str]] = []
    frames: list[pd.DataFrame] = []

    for label, target in [("subcritical_R0_0.70", 0.70), ("supercritical_R0_1.35", 1.35)]:
        params = set_beta_for_target_r0(base, baseline_contact, susceptibility, target)
        params = with_params(params, alpha_mode="variable", feedback_strength=3.0)
        append_run(
            metrics,
            frames,
            layers,
            baseline_weights,
            initial,
            susceptibility,
            params,
            "threshold",
            label,
        )

    params_rich = set_beta_for_target_r0(base, baseline_contact, susceptibility, 1.45)
    for label, mode, alpha in [
        ("constant_alpha_0.72", "constant", 0.72),
        ("constant_alpha_0.86", "constant", 0.86),
        ("constant_alpha_0.94", "constant", 0.94),
        ("variable_alpha_feedback", "variable", 0.86),
    ]:
        params = with_params(params_rich, alpha_mode=mode, alpha_constant=alpha, feedback_strength=3.0)
        append_run(
            metrics,
            frames,
            layers,
            baseline_weights,
            initial,
            susceptibility,
            params,
            "variable_order",
            label,
        )

    params_feedback = set_beta_for_target_r0(base, baseline_contact, susceptibility, 1.55)
    for feedback in [0.0, 2.0, 5.0]:
        params = with_params(
            params_feedback,
            alpha_mode="variable",
            feedback_strength=feedback,
        )
        append_run(
            metrics,
            frames,
            layers,
            baseline_weights,
            initial,
            susceptibility,
            params,
            "feedback",
            f"feedback_{feedback:.1f}",
        )

    network_scenarios = {
        "multilayer_baseline": baseline_weights,
        "online_only": {"online": 1.0, "offline": 0.0, "media": 0.0},
        "offline_only": {"online": 0.0, "offline": 1.0, "media": 0.0},
        "media_only": {"online": 0.0, "offline": 0.0, "media": 1.0},
        "balanced_layers": {"online": 1.0, "offline": 1.0, "media": 1.0},
    }
    params_network = set_beta_for_target_r0(base, baseline_contact, susceptibility, 1.45)
    params_network = with_params(params_network, alpha_mode="variable", feedback_strength=3.0)
    for label, weights in network_scenarios.items():
        append_run(
            metrics,
            frames,
            layers,
            weights,
            initial,
            susceptibility,
            params_network,
            "network_structure",
            label,
        )

    params_control_base = set_beta_for_target_r0(base, baseline_contact, susceptibility, 1.70)
    for label, rec, reduction in [
        ("no_control", 0.00, 0.00),
        ("weak_clarification", 0.04, 0.10),
        ("moderate_clarification", 0.08, 0.22),
        ("strong_clarification", 0.14, 0.35),
    ]:
        params = with_params(
            params_control_base,
            alpha_mode="variable",
            feedback_strength=3.0,
            intervention_recovery=rec,
            contact_reduction=reduction,
        )
        append_run(
            metrics,
            frames,
            layers,
            baseline_weights,
            initial,
            susceptibility,
            params,
            "intervention",
            label,
        )

    convergence = convergence_experiment(layers, initial, susceptibility, base, baseline_weights)
    variable_distinctiveness = variable_order_distinctiveness_experiment(
        layers, initial, susceptibility, base, baseline_weights
    )
    scheme_comparison = scheme_comparison_experiment(
        layers, initial, susceptibility, base, baseline_weights
    )
    scaling_heterogeneity = scaling_heterogeneity_experiment(base)

    metrics_df = pd.DataFrame(metrics)
    timeseries_df = pd.concat(frames, ignore_index=True)
    scenario_columns = [
        "scenario_group",
        "scenario",
        "horizon",
        "dt",
        "alpha_mode",
        "alpha_constant",
        "beta",
        "gamma",
        "xi",
        "feedback_strength",
        "intervention_recovery",
        "contact_reduction",
        "weight_online",
        "weight_offline",
        "weight_media",
        "spectral_radius",
        "contact_spectral_radius",
        "R0",
    ]
    for column in ["gamma", "xi"]:
        metrics_df[column] = getattr(base, column)
    preservation = metrics_df[
        [
            "scenario_group",
            "scenario",
            "min_state",
            "max_total_error",
            "final_S",
            "final_I",
            "final_R",
            "final_B",
            "min_alpha",
            "max_alpha",
            "max_B",
        ]
    ].copy()

    metrics_df.to_csv(TABLE_DIR / "experiment_metrics.csv", index=False)
    metrics_df[scenario_columns].to_csv(TABLE_DIR / "scenario_parameters.csv", index=False)
    preservation.to_csv(TABLE_DIR / "preservation_diagnostics.csv", index=False)
    timeseries_df.to_csv(TABLE_DIR / "mean_timeseries.csv", index=False)
    convergence.to_csv(TABLE_DIR / "convergence_table.csv", index=False)
    variable_distinctiveness.to_csv(
        TABLE_DIR / "variable_order_distinctiveness.csv", index=False
    )
    scheme_comparison.to_csv(TABLE_DIR / "scheme_comparison.csv", index=False)
    scaling_heterogeneity.to_csv(TABLE_DIR / "scaling_heterogeneity.csv", index=False)

    for group in [
        "threshold",
        "variable_order",
        "feedback",
        "network_structure",
        "intervention",
    ]:
        plot_group(timeseries_df, group, FIGURE_DIR / f"{group}_mean_I.png")
    plot_alpha(timeseries_df, FIGURE_DIR / "variable_order_alpha.png")
    write_summary(
        metrics_df,
        convergence,
        scheme_comparison,
        variable_distinctiveness,
        scaling_heterogeneity,
    )
    write_chinese_notes(
        metrics_df,
        convergence,
        scheme_comparison,
        variable_distinctiveness,
        scaling_heterogeneity,
    )

    print(f"Wrote tables to {TABLE_DIR}")
    print(f"Wrote figures to {FIGURE_DIR}")
    print(f"Wrote summary to {SUMMARY_PATH}")
    print(f"Wrote Chinese notes to {CHINESE_NOTES_PATH}")
    print(metrics_df[["scenario_group", "scenario", "R0", "peak_I", "final_I"]].to_string(index=False))
    print(convergence.to_string(index=False))
    print(scheme_comparison.to_string(index=False))


if __name__ == "__main__":
    main()
