"""Variable-order fractional multilayer information-spread model.

The model is intentionally compact enough for reproducible paper experiments while
matching the proposed manuscript structure:

- multilayer information pressure;
- variable-order memory through a Caputo L1 history term;
- behavioral feedback reducing effective transmission;
- a nonstandard implicit transition update preserving nonnegativity and S+I+R mass.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, replace
import json
import math
from pathlib import Path
from typing import Dict, Iterable, Mapping

import numpy as np


COMPARTMENTS = ("S", "I", "R", "B")


@dataclass(frozen=True)
class ModelParams:
    beta: float = 0.33
    gamma: float = 0.30
    xi: float = 0.018
    saturation: float = 0.40
    feedback_strength: float = 3.0
    awareness_gain: float = 0.50
    awareness_network_gain: float = 0.08
    awareness_decay: float = 0.42
    alpha_mode: str = "variable"
    alpha_constant: float = 0.86
    alpha_min: float = 0.72
    alpha_max: float = 0.94
    alpha_half: float = 0.12
    intervention_recovery: float = 0.0
    contact_reduction: float = 0.0


def params_to_json(params: ModelParams, path: Path) -> None:
    path.write_text(json.dumps(asdict(params), indent=2, sort_keys=True) + "\n")


def params_from_json(path: Path) -> ModelParams:
    return ModelParams(**json.loads(path.read_text()))


def with_params(params: ModelParams, **updates: float | str) -> ModelParams:
    return replace(params, **updates)


def contact_matrix_from_layers(
    layers: Mapping[str, np.ndarray],
    weights: Mapping[str, float],
) -> np.ndarray:
    """Build an aggregate contact operator from layer adjacency matrices.

    Each layer is normalized by its average degree. This keeps the layer units
    comparable but still allows heterogeneous layers to have different spectral
    radii, which is useful for threshold and network-structure experiments.
    """

    names = list(layers)
    n = next(iter(layers.values())).shape[0]
    contact = np.zeros((n, n), dtype=float)
    weight_sum = sum(max(0.0, float(weights.get(name, 0.0))) for name in names)
    if weight_sum <= 0:
        raise ValueError("At least one layer weight must be positive.")

    for name in names:
        weight = max(0.0, float(weights.get(name, 0.0))) / weight_sum
        adjacency = np.asarray(layers[name], dtype=float)
        avg_degree = adjacency.sum(axis=1).mean()
        if avg_degree <= 0:
            continue
        contact += weight * adjacency / avg_degree
    np.fill_diagonal(contact, 0.0)
    return contact


def spectral_radius(matrix: np.ndarray) -> float:
    values = np.linalg.eigvals(matrix)
    return float(np.max(np.abs(values)))


def threshold_matrix(contact: np.ndarray, susceptibility: np.ndarray) -> np.ndarray:
    """Return QW, the linearized infection contact operator."""

    return np.asarray(susceptibility, dtype=float)[:, None] * np.asarray(contact, dtype=float)


def reproduction_number(
    contact: np.ndarray, susceptibility: np.ndarray, params: ModelParams
) -> float:
    beta_eff = params.beta * (1.0 - params.contact_reduction)
    gamma_eff = params.gamma + params.intervention_recovery
    return beta_eff * spectral_radius(threshold_matrix(contact, susceptibility)) / gamma_eff


def alpha_value(params: ModelParams, behavior_mean: float) -> float:
    if params.alpha_mode == "constant":
        alpha = params.alpha_constant
    elif params.alpha_mode == "variable":
        reduction = behavior_mean / (behavior_mean + params.alpha_half + 1e-12)
        alpha = params.alpha_max - (params.alpha_max - params.alpha_min) * reduction
    else:
        raise ValueError(f"Unknown alpha_mode: {params.alpha_mode}")
    return float(alpha)


def l1_history(history: np.ndarray, alpha: float) -> np.ndarray:
    """Return the positive L1 history term H_n.

    If `history` contains x_0, ..., x_{n-1}, then

        D_C^alpha x(t_n) approx (x_n - H_n) / (Gamma(2-alpha) h^alpha).

    The coefficients sum to one, so constants are preserved by H_n.
    """

    n = history.shape[0]
    j = np.arange(n, dtype=float)
    a = (j + 1.0) ** (1.0 - alpha) - j ** (1.0 - alpha)
    coeff = np.empty(n, dtype=float)
    coeff[0] = a[n - 1]
    for k in range(1, n):
        coeff[k] = a[n - k - 1] - a[n - k]
    return np.tensordot(coeff, history, axes=(0, 0))


def solve_transition_step(
    history_state: np.ndarray,
    lambda_rate: np.ndarray,
    gamma_eff: float,
    xi: float,
    delta: float,
) -> np.ndarray:
    """Implicit nonstandard S-I-R transition update for one time step."""

    n_nodes = history_state.shape[0]
    out = np.zeros((n_nodes, 3), dtype=float)
    for i in range(n_nodes):
        lam = float(lambda_rate[i])
        mat = np.array(
            [
                [1.0 + delta * lam, 0.0, -delta * xi],
                [-delta * lam, 1.0 + delta * gamma_eff, 0.0],
                [0.0, -delta * gamma_eff, 1.0 + delta * xi],
            ],
            dtype=float,
        )
        out[i] = np.linalg.solve(mat, history_state[i, :3])
    return out


def simulate(
    initial_state: np.ndarray,
    contact: np.ndarray,
    susceptibility: np.ndarray,
    params: ModelParams,
    horizon: float = 50.0,
    dt: float = 0.2,
) -> Dict[str, np.ndarray | float]:
    """Simulate the variable-order model.

    Returns full node-level states plus aggregate diagnostic series. The solver is
    deterministic for fixed inputs.
    """

    initial_state = np.asarray(initial_state, dtype=float)
    if initial_state.ndim != 2 or initial_state.shape[1] != len(COMPARTMENTS):
        raise ValueError("initial_state must have shape (n_nodes, 4).")

    steps = int(round(horizon / dt))
    times = np.linspace(0.0, steps * dt, steps + 1)
    states = np.zeros((steps + 1, *initial_state.shape), dtype=float)
    states[0] = initial_state
    alphas = np.zeros(steps + 1, dtype=float)
    alphas[0] = alpha_value(params, float(initial_state[:, 3].mean()))
    min_state = float(np.min(initial_state))
    total_error = 0.0

    for n in range(1, steps + 1):
        previous = states[n - 1]
        behavior_mean = float(previous[:, 3].mean())
        alpha = alpha_value(params, behavior_mean)
        alphas[n] = alpha
        delta = math.gamma(2.0 - alpha) * (dt**alpha)
        history_term = l1_history(states[:n], alpha)

        pressure = contact @ previous[:, 1]
        beta_eff = params.beta * (1.0 - params.contact_reduction)
        lambda_rate = (
            beta_eff
            * susceptibility
            * pressure
            / (1.0 + params.saturation * pressure)
            / (1.0 + params.feedback_strength * previous[:, 3])
        )
        gamma_eff = params.gamma + params.intervention_recovery

        sir = solve_transition_step(
            history_term, lambda_rate, gamma_eff, params.xi, delta
        )
        behavior = (
            history_term[:, 3]
            + delta
            * (
                params.awareness_gain * previous[:, 1]
                + params.awareness_network_gain * pressure
            )
        ) / (1.0 + delta * params.awareness_decay)
        states[n, :, :3] = sir
        states[n, :, 3] = behavior

        min_state = min(min_state, float(states[n].min()))
        total_error = max(
            total_error, float(np.max(np.abs(states[n, :, :3].sum(axis=1) - 1.0)))
        )

    means = states.mean(axis=1)
    return {
        "times": times,
        "states": states,
        "mean": means,
        "alphas": alphas,
        "min_state": min_state,
        "max_total_error": total_error,
        "r0": reproduction_number(contact, susceptibility, params),
    }


def simulate_explicit_l1(
    initial_state: np.ndarray,
    contact: np.ndarray,
    susceptibility: np.ndarray,
    params: ModelParams,
    horizon: float = 50.0,
    dt: float = 0.2,
) -> Dict[str, np.ndarray | float]:
    """Simulate a standard explicit L1 discretization for comparison.

    This method intentionally lacks the implicit NSFD transition used by
    `simulate`. It is used only as a non-structure-preserving baseline.
    """

    initial_state = np.asarray(initial_state, dtype=float)
    steps = int(round(horizon / dt))
    times = np.linspace(0.0, steps * dt, steps + 1)
    states = np.zeros((steps + 1, *initial_state.shape), dtype=float)
    states[0] = initial_state
    alphas = np.zeros(steps + 1, dtype=float)
    alphas[0] = alpha_value(params, float(initial_state[:, 3].mean()))
    min_state = float(np.min(initial_state))
    total_error = 0.0

    for n in range(1, steps + 1):
        previous = states[n - 1]
        alpha = alpha_value(params, float(previous[:, 3].mean()))
        alphas[n] = alpha
        delta = math.gamma(2.0 - alpha) * (dt**alpha)
        history_term = l1_history(states[:n], alpha)

        pressure = contact @ previous[:, 1]
        beta_eff = params.beta * (1.0 - params.contact_reduction)
        lambda_rate = (
            beta_eff
            * susceptibility
            * pressure
            / (1.0 + params.saturation * pressure)
            / (1.0 + params.feedback_strength * previous[:, 3])
        )
        gamma_eff = params.gamma + params.intervention_recovery

        states[n, :, 0] = history_term[:, 0] + delta * (
            -lambda_rate * previous[:, 0] + params.xi * previous[:, 2]
        )
        states[n, :, 1] = history_term[:, 1] + delta * (
            lambda_rate * previous[:, 0] - gamma_eff * previous[:, 1]
        )
        states[n, :, 2] = history_term[:, 2] + delta * (
            gamma_eff * previous[:, 1] - params.xi * previous[:, 2]
        )
        states[n, :, 3] = history_term[:, 3] + delta * (
            params.awareness_gain * previous[:, 1]
            + params.awareness_network_gain * pressure
            - params.awareness_decay * previous[:, 3]
        )

        min_state = min(min_state, float(states[n].min()))
        total_error = max(
            total_error, float(np.max(np.abs(states[n, :, :3].sum(axis=1) - 1.0)))
        )

    return {
        "times": times,
        "states": states,
        "mean": states.mean(axis=1),
        "alphas": alphas,
        "min_state": min_state,
        "max_total_error": total_error,
        "r0": reproduction_number(contact, susceptibility, params),
    }


def summarize_run(
    result: Mapping[str, np.ndarray | float],
    scenario_group: str,
    scenario: str,
    params: ModelParams,
) -> Dict[str, float | str]:
    times = np.asarray(result["times"], dtype=float)
    mean = np.asarray(result["mean"], dtype=float)
    alphas = np.asarray(result["alphas"], dtype=float)
    infected = mean[:, 1]
    peak_index = int(np.argmax(infected))
    return {
        "scenario_group": scenario_group,
        "scenario": scenario,
        "alpha_mode": params.alpha_mode,
        "alpha_constant": params.alpha_constant,
        "feedback_strength": params.feedback_strength,
        "intervention_recovery": params.intervention_recovery,
        "contact_reduction": params.contact_reduction,
        "beta": params.beta,
        "R0": float(result["r0"]),
        "peak_I": float(infected[peak_index]),
        "peak_time": float(times[peak_index]),
        "final_S": float(mean[-1, 0]),
        "final_I": float(mean[-1, 1]),
        "final_R": float(mean[-1, 2]),
        "final_B": float(mean[-1, 3]),
        "initial_alpha": float(alphas[0]),
        "final_alpha": float(alphas[-1]),
        "min_alpha": float(alphas.min()),
        "max_alpha": float(alphas.max()),
        "max_B": float(np.max(np.asarray(result["states"], dtype=float)[:, :, 3])),
        "min_state": float(result["min_state"]),
        "max_total_error": float(result["max_total_error"]),
    }


def mean_timeseries_frame(
    result: Mapping[str, np.ndarray | float],
    scenario_group: str,
    scenario: str,
) -> Dict[str, Iterable[float | str]]:
    times = np.asarray(result["times"], dtype=float)
    mean = np.asarray(result["mean"], dtype=float)
    alphas = np.asarray(result["alphas"], dtype=float)
    return {
        "scenario_group": [scenario_group] * len(times),
        "scenario": [scenario] * len(times),
        "t": times,
        "S_mean": mean[:, 0],
        "I_mean": mean[:, 1],
        "R_mean": mean[:, 2],
        "B_mean": mean[:, 3],
        "alpha": alphas,
    }
