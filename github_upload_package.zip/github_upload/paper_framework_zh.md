# 论文框架建议

## 拟题

英文题目建议：

**Threshold-preserving numerical analysis for a variable-order fractional multilayer information-spread model with behavioral feedback**

中文工作题目：

**具有行为反馈的变阶分数阶多层信息传播模型及阈值保持数值分析**

## 总体定位

本文建议写成一篇偏 Applied Mathematics and Computation 风格的数学建模与数值分析论文：先提出一个具有多层网络、变阶记忆和行为反馈的信息传播模型，再给出阈值动力学与保结构 L1-NSFD 数值格式，最后用可复现实验验证阈值、非负性、收敛性和干预效果。

建议全文控制在 **26-29 页**，其中正文约 22-24 页，参考文献约 3-4 页。不要设置过长附录；证明以“主结论清楚、代数推导压缩”为原则。

## 核心创新点

1. **模型创新**：构造变阶 Caputo 型分数阶多层信息传播模型，将线上社交层、线下接触层和媒体传播层统一到加权接触算子中。
2. **机制创新**：引入行为反馈变量，反馈既抑制有效传播率，又调节分数阶阶数，从而刻画“风险感知增强时记忆效应改变”的传播机制。
3. **理论创新**：基于多层接触矩阵谱半径定义基本再生数，分析无传播平衡点、正性有界性和阈值型传播规律。
4. **算法创新**：构造 L1-NSFD 格式，使离散解保持非负性、节点内总量守恒和阈值动力学一致性。
5. **实验创新**：在可复现三层合成网络上验证收敛性、阈值响应、变阶影响、行为反馈、多层结构差异和澄清干预效果，并进行多随机种子稳健性检验。

## 建议篇幅分配

| 部分 | 内容 | 页数 |
|---|---|---:|
| Abstract + keywords | 摘要、关键词 | 0.5 |
| 1 Introduction | 背景、文献、研究空缺、贡献 | 3 |
| 2 Model formulation | 预备知识、多层网络、变阶模型 | 4 |
| 3 Qualitative and threshold analysis | 正性、有界性、平衡点、基本再生数、阈值结论 | 5 |
| 4 Structure-preserving numerical scheme | L1 离散、NSFD 格式、保持性、收敛讨论 | 5 |
| 5 Numerical experiments | 数据、图表、对比实验、稳健性 | 7 |
| 6 Conclusion | 总结、局限、未来工作 | 1.5 |
| References | 参考文献 | 3-4 |
| **合计** |  | **29 左右** |

## 摘要结构

摘要控制在 180-230 词，按四句话组织：

1. 多层网络信息传播受到记忆效应和行为反馈共同影响，传统整数阶或固定阶模型难以同时刻画这些因素。
2. 本文提出一个变阶分数阶多层信息传播模型，定义有效传播压力和反馈诱导的阶数函数，并给出基本再生数。
3. 构造 L1-NSFD 数值格式，证明其非负性、守恒性和阈值保持性质。
4. 数值实验表明，反馈增强和澄清干预可显著降低传播峰值；强干预将有效再生数压低到 1 以下，多随机种子检验支持结论稳健。

关键词建议：

variable-order fractional derivative; multilayer networks; information spreading; behavioral feedback; threshold dynamics; nonstandard finite difference.

## 1 Introduction

目标：用 3 页把问题说清楚，不做长篇文献综述。

建议段落：

1. 信息、谣言和风险感知传播具有多渠道、多时间尺度和行为适应性。
2. 多层网络比单层网络更适合描述线上、线下和媒体共同作用。
3. 分数阶模型能描述记忆效应，但固定阶模型难以表达传播过程中记忆强度的动态变化。
4. 行为反馈、澄清机制和风险感知会改变接触率、传播率或恢复率。
5. 现有工作不足：多层网络、变阶分数阶、行为反馈和保阈值数值格式往往分开处理，缺少统一框架。
6. 本文贡献，建议列 4 条即可：
   - 提出变阶分数阶多层信息传播模型；
   - 建立正性、有界性和基本再生数阈值分析；
   - 构造保持非负性和总量守恒的 L1-NSFD 格式；
   - 通过可复现实验验证变阶、反馈、网络结构和干预策略的影响。

文献放置：

- 多层网络与谣言传播：Di et al., Velasquez-Rojas et al., Wang and Perc, Wan et al.
- 分数阶谣言传播与澄清机制：Ye et al., Li et al., Ali et al., Niu et al.
- 变阶分数阶与 L1 方法：Wu et al., Almeida and Torres, Liu et al.
- 保正性/NSFD：Cui et al., Arenas et al., Khan et al., Zhang.

## 2 Model formulation

目标：4 页内完成符号、网络算子和模型构建。

### 2.1 Multilayer contact operator

设有 \(N\) 个节点和 \(L\) 个网络层。第 \(\ell\) 层邻接矩阵为 \(A^{(\ell)}\)，层权重为 \(\omega_\ell\)，构造归一化聚合接触矩阵

\[
W=\sum_{\ell=1}^{L}\omega_\ell \frac{A^{(\ell)}}{\bar d_\ell},\qquad
\sum_{\ell=1}^{L}\omega_\ell=1.
\]

归一化的意义：避免某一层仅因平均度较高而支配传播，同时保留谱半径差异。

### 2.2 State variables

每个节点 \(i\) 具有

\[
S_i(t),\quad I_i(t),\quad R_i(t),\quad B_i(t),
\]

分别表示易感、传播、恢复或免疫、行为反馈强度。节点内满足

\[
S_i(t)+I_i(t)+R_i(t)=1,\qquad B_i(t)\in[0,1].
\]

建议用一个符号表，不超过半页。

### 2.3 Transmission pressure and behavioral feedback

传播压力：

\[
P_i(t)=\sum_{j=1}^{N} W_{ij}I_j(t).
\]

有效传播率：

\[
\lambda_i(t)=
\frac{\beta q_i P_i(t)}
{\left(1+aP_i(t)\right)\left(1+\kappa B_i(t)\right)},
\]

其中 \(q_i\) 为异质易感性，\(a\) 为饱和参数，\(\kappa\) 为反馈抑制强度。

### 2.4 Variable-order memory

建议采用平均行为反馈驱动的阶数函数：

\[
\alpha(t)=\alpha_{\max}-(\alpha_{\max}-\alpha_{\min})
\frac{\bar B(t)}{\bar B(t)+h_\alpha},
\qquad
\bar B(t)=\frac1N\sum_{i=1}^N B_i(t).
\]

解释：当反馈增强时，传播系统的有效记忆阶数发生变化；\(\alpha(t)\in[\alpha_{\min},\alpha_{\max}]\)。

### 2.5 Full model

建议模型写成：

\[
{}^C D_t^{\alpha(t)}S_i
=-\lambda_i(t)S_i+\xi R_i,
\]

\[
{}^C D_t^{\alpha(t)}I_i
=\lambda_i(t)S_i-\gamma I_i,
\]

\[
{}^C D_t^{\alpha(t)}R_i
=\gamma I_i-\xi R_i,
\]

\[
{}^C D_t^{\alpha(t)}B_i
=\eta I_i+\mu P_i-\delta B_i.
\]

这里 \(\gamma\) 为恢复或澄清率，\(\xi\) 为遗忘或免疫衰退率，\(\eta,\mu,\delta\) 描述行为反馈的生成与衰减。

## 3 Qualitative and threshold analysis

目标：证明主结论，不要把每一步代数都铺满。建议 4 个定理。

### 3.1 Positivity and boundedness

定理 1：若初值满足

\[
S_i(0),I_i(0),R_i(0),B_i(0)\ge0,\qquad S_i(0)+I_i(0)+R_i(0)=1,
\]

且参数非负，则解保持非负，并满足

\[
S_i(t)+I_i(t)+R_i(t)=1,\qquad 0\le B_i(t)\le B_{\max}.
\]

证明思路：

- 在坐标边界上检查向量场方向；
- 三个传播状态方程相加得到守恒；
- 行为变量由输入项和衰减项给出比较估计。

### 3.2 Disease-free equilibrium

无传播平衡点建议写为

\[
E_0=(S^0,I^0,R^0,B^0)=(\mathbf 1,\mathbf 0,\mathbf 0,\mathbf 0).
\]

若考虑背景行为反馈，也可写成 \(B^0\ge0\)，但为了阈值公式简洁，建议主文采用 \(B^0=0\)。

### 3.3 Basic reproduction number

在 \(E_0\) 附近线性化，得到感染子系统近似

\[
{}^C D_t^{\alpha_0} I
=\left(\beta QW-\gamma I_N\right)I,
\]

其中 \(Q=\mathrm{diag}(q_i)\)。因此

\[
\mathcal R_0=\frac{\beta}{\gamma}\rho(QW).
\]

若加入干预参数，如接触削减 \(c\) 和额外澄清恢复 \(u\)，可写为

\[
\mathcal R_c=
\frac{\beta(1-c)}{\gamma+u}\rho(QW).
\]

### 3.4 Threshold theorem

定理 2：若 \(\mathcal R_0<1\)，无传播平衡点局部渐近稳定；若 \(\mathcal R_0>1\)，无传播平衡点不稳定，传播可入侵。

可选加强结论：在适当单调性或小规模反馈条件下，\(\mathcal R_0<1\) 时 \(I(t)\to0\)。

### 3.5 Sensitivity discussion

这里不要再做一个大定理，写成命题或讨论即可：

\[
\frac{\partial \mathcal R_c}{\partial c}<0,\qquad
\frac{\partial \mathcal R_c}{\partial u}<0.
\]

解释接触削减和澄清恢复均降低有效再生数；层权重通过 \(\rho(QW)\) 改变阈值。

## 4 Structure-preserving numerical scheme

目标：把算法作为本文第二个核心。建议 5 页。

### 4.1 Variable-order L1 approximation

时间网格 \(t_n=nh\)。对变阶 Caputo 导数使用 L1 近似：

\[
{}^C D_t^{\alpha_n}x(t_n)
\approx
\frac{x^n-H^n_{\alpha_n}(x)}
{\Gamma(2-\alpha_n)h^{\alpha_n}},
\]

其中 \(H^n_{\alpha_n}\) 为历史加权项，权重非负且和为 1。强调该性质是常数保持和正性保持的关键。

### 4.2 L1-NSFD update

记

\[
\Delta_n=\Gamma(2-\alpha_n)h^{\alpha_n}.
\]

对 \(S,I,R\) 使用隐式 NSFD 转移格式：

\[
\frac{S_i^n-H_i^n(S)}{\Delta_n}
=-\lambda_i^{n-1}S_i^n+\xi R_i^n,
\]

\[
\frac{I_i^n-H_i^n(I)}{\Delta_n}
=\lambda_i^{n-1}S_i^n-\gamma I_i^n,
\]

\[
\frac{R_i^n-H_i^n(R)}{\Delta_n}
=\gamma I_i^n-\xi R_i^n.
\]

行为反馈变量：

\[
\frac{B_i^n-H_i^n(B)}{\Delta_n}
=\eta I_i^{n-1}+\mu P_i^{n-1}-\delta B_i^n.
\]

这里 \(\lambda_i^{n-1}\) 和 \(P_i^{n-1}\) 显式计算，转移项隐式处理，兼顾保持性与计算成本。

### 4.3 Positivity and conservation of the scheme

定理 3：若历史项非负，且初值非负，则数值解满足

\[
S_i^n,I_i^n,R_i^n,B_i^n\ge0,
\qquad
S_i^n+I_i^n+R_i^n=1.
\]

证明重点：

- 三变量线性系统是 M-矩阵型结构；
- 右端历史项非负；
- 三个方程相加得到离散守恒。

### 4.4 Threshold preservation

定理 4：对线性化感染子系统，若 \(\mathcal R_0<1\)，离散感染变量不产生虚假增长；若 \(\mathcal R_0>1\)，离散格式保留入侵方向。

这里不必过度追求最强结论，重点是说明数值格式不会破坏连续模型的阈值判断。

### 4.5 Algorithm

给出一个 8-10 行伪代码即可：

1. 读取多层网络并构造 \(W\)；
2. 初始化状态变量；
3. 对每个时间步计算 \(\bar B^{n-1}\)、\(\alpha_n\)、历史项；
4. 计算传播压力 \(P^{n-1}\) 和传播率 \(\lambda^{n-1}\)；
5. 解每个节点的三维隐式转移系统；
6. 更新行为变量；
7. 输出均值、峰值、最终值和保持性诊断。

## 5 Numerical experiments

目标：7 页内用结果支撑全部理论和机制。建议主文保留 5 幅图、3 张表，其余结果作为可复现材料说明。

### 5.1 Dataset and settings

数据描述：

- 节点数：\(N=120\)；
- 线上层：无标度网络；
- 线下层：小世界网络；
- 媒体层：随机广播网络；
- 初始传播者：6 个高连接度节点；
- 节点具有异质易感性；
- 随机种子固定，可复现。

对应文件：

- `data/synthetic/nodes.csv`
- `data/synthetic/edges_online.csv`
- `data/synthetic/edges_offline.csv`
- `data/synthetic/edges_media.csv`

### 5.2 Numerical preservation and convergence

主文表 1：合并保持性和收敛性。

可写结论：

- 所有实验中状态变量最小值为 \(0.000\times10^0\)；
- 最大节点内守恒误差为 \(3.775\times10^{-15}\)；
- 步长从 0.4 到 0.1 时，感染均值 RMS 误差从 \(3.59\times10^{-4}\) 降至 \(5.63\times10^{-5}\)。

### 5.3 Threshold verification

使用图 `outputs/figures/threshold_mean_I.png`。

主结论：

- \(\mathcal R_0=0.70\) 时，最终传播比例约为 0.00020；
- \(\mathcal R_0=1.35\) 时，最终传播比例约为 0.01675；
- 实验与阈值理论一致。

### 5.4 Variable-order effect

建议把 `variable_order_mean_I.png` 和 `variable_order_alpha.png` 合并成一幅双子图。

主结论：

- 固定阶 \(\alpha=0.72,0.86,0.94\) 下，阶数越高，传播峰值越高且峰值更早；
- 反馈诱导变阶情形的峰值和峰值时间介于固定阶情形之间；
- 变阶机制提供了比固定阶模型更灵活的传播记忆描述。

### 5.5 Behavioral feedback effect

使用图 `outputs/figures/feedback_mean_I.png`。

主结论：

- 反馈强度从 0 增至 5 时，峰值 \(I\) 从 0.04663 降至 0.02378；
- 最终 \(I\) 从 0.03842 降至 0.02179；
- 行为响应显著削弱传播压力。

### 5.6 Multilayer network structure

使用图 `outputs/figures/network_structure_mean_I.png`。

主结论：

- online only 情形谱半径最高，\(\mathcal R_0=1.95907\)，峰值最高；
- offline only 情形传播较弱，\(\mathcal R_0=1.19297\)；
- 多层结构改变谱半径，从而改变传播阈值和传播规模。

### 5.7 Intervention and clarification

使用图 `outputs/figures/intervention_mean_I.png`。

主结论：

- 无控制：\(\mathcal R_0=1.70\)，最终 \(I=0.03159\)；
- 强澄清：\(\mathcal R_0=0.75341\)，最终 \(I=0.00013\)；
- 澄清强度与接触削减共同作用，可把系统推入亚临界区域。

### 5.8 Robustness checks

这一节压缩到半页，使用图 `outputs/figures/robustness_key_claims.png` 或小表。

主结论：

- 8 个随机网络种子下，反馈抑制、强干预和阈值响应的通过率均为 1.000；
- 说明结论不是单一随机网络实现的偶然现象。

## 6 Conclusion

控制在 1.5 页以内。

建议写三段：

1. 总结模型：本文提出了变阶分数阶多层信息传播模型，将多层网络、行为反馈和记忆阶数变化结合起来。
2. 总结理论和算法：给出基本再生数、阈值分析和保持非负性/守恒性的 L1-NSFD 格式。
3. 总结实验和未来工作：实验验证反馈与干预的有效性；未来可考虑真实平台数据、参数反演、最优控制、随机扰动和时变网络。

## 图表精简方案

建议主文保留：

1. 图 1：模型机制示意或三层网络示意，可选；
2. 图 2：阈值验证；
3. 图 3：变阶传播曲线与 \(\alpha(t)\) 曲线，双子图；
4. 图 4：行为反馈与干预效果，双子图；
5. 图 5：多层网络结构对比；
6. 图 6：稳健性检验，可选。

建议主文保留表格：

1. 表 1：符号和参数；
2. 表 2：保持性诊断与收敛性；
3. 表 3：关键情景指标汇总。

如果页数紧张，删除图 1，把稳健性检验只写成文字或小表。

## 30 页以内的写作控制

1. 引言最多 3 页，不逐篇展开文献，只按主题分组综述。
2. 模型部分避免重复解释常见分数阶定义，只给本文需要的定义。
3. 理论部分每个定理只保留关键证明，技术细节用“由比较原理/M-矩阵性质可得”压缩。
4. 数值部分不要把所有 CSV 表都放进主文，只展示能支撑核心结论的指标。
5. 参考文献控制在 25-35 篇左右。
6. 图尽量合并成双子图，表格只放汇总表。

## 推荐写作顺序

1. 先写第 2 节模型，因为符号会决定全文；
2. 再写第 4 节数值格式，与已有代码完全对应；
3. 写第 5 节数值实验，直接使用当前输出图表和数值；
4. 回头写第 3 节理论，把定理与数值格式对齐；
5. 最后写引言、摘要和结论。

## 需要特别注意的风险

1. 如果论文标题强调 “threshold-preserving”，理论部分必须明确连续阈值和离散阈值之间的关系。
2. 如果强调 “variable-order”，需要清楚说明 \(\alpha(t)\) 的取值范围、光滑性或有界性假设。
3. 如果行为反馈同时影响传播率和阶数，要避免过度声称因果机制；可以表述为“phenomenological behavioral feedback”。
4. 数值实验目前是合成网络，论文中应诚实说明其目标是机制验证和算法验证，而不是对某一真实平台的预测。
5. 代码中的可复现性是优势，建议在论文末尾加 Data and code availability 说明。
