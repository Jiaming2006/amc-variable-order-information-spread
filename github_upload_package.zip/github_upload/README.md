# AMC numerical experiment workspace

This workspace builds a reproducible synthetic dataset and numerical results for the
topic:

> Threshold-preserving numerical analysis for a variable-order fractional multilayer
> information-spread model with behavioral feedback.

The current reference-paper structure suggests the following computational section:

1. convergence and consistency checks for the positivity-preserving scheme;
2. effects of variable fractional order;
3. effects of behavioral feedback;
4. multilayer network-structure comparison;
5. intervention / clarification strategy comparison.

## Files

- `references_amc_topic_pdfs/`: reference papers and the topic index.
- `src/build_dataset.py`: creates the synthetic multilayer information-spread dataset.
- `src/model.py`: variable-order fractional multilayer model and L1-NSFD solver.
- `src/run_experiments.py`: runs all numerical experiments and writes result tables/figures.
- `src/robustness_analysis.py`: repeats the key claims over multiple synthetic-network
  seeds to check that conclusions are not tied to one random realization.
- `src/validate_results.py`: checks dataset integrity, numerical preservation, monotonic
  response patterns, convergence trends, deterministic reproducibility, and output hashes.
- `data/synthetic/`: generated node metadata, layer edge lists, and baseline parameters.
- `outputs/tables/`: CSV result tables.
- `outputs/figures/`: plot images for the paper's numerical-experiment section.
- `outputs/results_summary.md`: concise result summary.
- `outputs/numerical_experiments_zh.md`: Chinese notes that can be adapted into the
  numerical-experiment section.
- `outputs/robustness_summary.md`: multi-seed robustness summary.
- `outputs/validation_report.md`: pass/fail reliability report.
- `outputs/output_manifest.csv`: file sizes and SHA-256 hashes for reproducibility.

## Run

```bash
python3 src/build_dataset.py
python3 src/run_experiments.py
python3 src/robustness_analysis.py
python3 src/validate_results.py
```

The scripts use fixed random seeds so the generated dataset and result values are
reproducible.
