# Robustness summary

Repeated the key numerical claims over 20 synthetic multilayer-network seeds.

## Aggregate results

| scenario_group   | scenario              |   n_seeds |   R0_mean |   R0_std |   peak_I_mean |   peak_I_std |   final_I_mean |   final_I_std |   final_I_min |   final_I_max |
|:-----------------|:----------------------|----------:|----------:|---------:|--------------:|-------------:|---------------:|--------------:|--------------:|--------------:|
| feedback         | feedback_0.0          |        20 |  1.550000 | 0.000000 |      0.043066 |     0.003422 |       0.043031 |      0.003450 |      0.036003 |      0.049704 |
| feedback         | feedback_5.0          |        20 |  1.550000 | 0.000000 |      0.022222 |     0.001613 |       0.022221 |      0.001613 |      0.018884 |      0.025411 |
| intervention     | no_control            |        20 |  1.700000 | 0.000000 |      0.036497 |     0.002530 |       0.035863 |      0.002500 |      0.030701 |      0.040824 |
| intervention     | strong_clarification  |        20 |  0.753409 | 0.000000 |      0.002738 |     0.000025 |       0.000265 |      0.000011 |      0.000247 |      0.000285 |
| threshold        | subcritical_R0_0.70   |        20 |  0.700000 | 0.000000 |      0.002705 |     0.000007 |       0.000394 |      0.000016 |      0.000369 |      0.000419 |
| threshold        | supercritical_R0_1.35 |        20 |  1.350000 | 0.000000 |      0.015428 |     0.001149 |       0.015428 |      0.001149 |      0.013104 |      0.017655 |

## Claim pass rates

| check                |   passed |
|:---------------------|---------:|
| feedback_suppression |    1.000 |
| strong_intervention  |    1.000 |
| threshold_final_I    |    1.000 |
