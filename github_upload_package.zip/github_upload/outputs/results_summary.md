# Numerical results summary

## Dataset

- Synthetic three-layer network: online scale-free, offline small-world, media random-broadcast.
- Node-level initial state uses six high-degree seed nodes and heterogeneous susceptibility.

## Threshold check

| scenario              |      R0 |   peak_I |   final_I |
|:----------------------|--------:|---------:|----------:|
| subcritical_R0_0.70   | 0.70000 |  0.00272 |   0.00020 |
| supercritical_R0_1.35 | 1.35000 |  0.01737 |   0.01704 |

## Variable-order effect

| scenario                |      R0 |   peak_I |   peak_time |   final_alpha |
|:------------------------|--------:|---------:|------------:|--------------:|
| constant_alpha_0.72     | 1.45000 |  0.01982 |    50.00000 |       0.72000 |
| constant_alpha_0.86     | 1.45000 |  0.02302 |    43.80000 |       0.86000 |
| constant_alpha_0.94     | 1.45000 |  0.02400 |    35.00000 |       0.94000 |
| variable_alpha_feedback | 1.45000 |  0.02345 |    38.20000 |       0.89424 |

## Intervention comparison

| scenario               |      R0 |   peak_I |   final_I |
|:-----------------------|--------:|---------:|----------:|
| moderate_clarification | 1.04684 |  0.00409 |   0.00289 |
| no_control             | 1.70000 |  0.03947 |   0.03181 |
| strong_clarification   | 0.75341 |  0.00277 |   0.00013 |
| weak_clarification     | 1.35000 |  0.01719 |   0.01599 |

## Behavioral feedback comparison

| scenario     |      R0 |   feedback_strength |   peak_I |   final_I |
|:-------------|--------:|--------------------:|---------:|----------:|
| feedback_0.0 | 1.55000 |             0.00000 |  0.04732 |   0.03871 |
| feedback_2.0 | 1.55000 |             2.00000 |  0.03384 |   0.02955 |
| feedback_5.0 | 1.55000 |             5.00000 |  0.02411 |   0.02202 |

## Multilayer network comparison

| scenario            |   spectral_radius |      R0 |   peak_I |   final_I |
|:--------------------|------------------:|--------:|---------:|----------:|
| balanced_layers     |           1.14484 | 1.34899 |  0.01983 |   0.01971 |
| media_only          |           1.28823 | 1.51794 |  0.02594 |   0.02507 |
| multilayer_baseline |           1.23057 | 1.45000 |  0.02345 |   0.02210 |
| offline_only        |           1.07416 | 1.26570 |  0.01261 |   0.01261 |
| online_only         |           1.61213 | 1.89960 |  0.03748 |   0.02572 |

## Convergence estimate

|       dt |   rms_error_I |   estimated_order |
|---------:|--------------:|------------------:|
| 0.400000 |      0.000416 |        nan        |
| 0.200000 |      0.000214 |          0.958358 |
| 0.100000 |      0.000103 |          1.050022 |
| 0.050000 |      0.000045 |          1.194550 |
| 0.025000 |      0.000015 |          1.568900 |

## Scheme comparison

| method               |   target_Rc |       dt |   horizon |   min_state |   negative_entries |   max_total_error |   peak_I |   final_I |
|:---------------------|------------:|---------:|----------:|------------:|-------------------:|------------------:|---------:|----------:|
| L1-NSFD              |    3.000000 | 4.000000 | 20.000000 |    0.000000 |                  0 |          0.000000 | 0.078295 |  0.078295 |
| standard_explicit_L1 |    3.000000 | 4.000000 | 20.000000 |   -0.009237 |                114 |          0.000000 | 0.315046 |  0.315046 |

## Variable-order distinctiveness

| case                  |   target_Rc |   horizon |       dt |   variable_alpha_min |   variable_alpha_max |   variable_alpha_mean |   variable_alpha_final |   variable_peak_I |   variable_peak_time |   variable_final_I |   best_constant_alpha |   best_constant_rms_mismatch |   best_constant_relative_rms |   best_constant_peak_I |   best_constant_peak_time |   best_constant_final_I |   best_constant_peak_abs_mismatch |   best_constant_peak_time_abs_mismatch |   best_constant_final_abs_mismatch |   peak_matched_alpha |   peak_matched_rms_mismatch |   peak_matched_peak_abs_mismatch |   peak_matched_peak_time_abs_mismatch |   peak_matched_final_abs_mismatch |   final_matched_alpha |   final_matched_rms_mismatch |   final_matched_peak_abs_mismatch |   final_matched_peak_time_abs_mismatch |   final_matched_final_abs_mismatch |
|:----------------------|------------:|----------:|---------:|---------------------:|---------------------:|----------------------:|-----------------------:|------------------:|---------------------:|-------------------:|----------------------:|-----------------------------:|-----------------------------:|-----------------------:|--------------------------:|------------------------:|----------------------------------:|---------------------------------------:|-----------------------------------:|---------------------:|----------------------------:|---------------------------------:|--------------------------------------:|----------------------------------:|----------------------:|-----------------------------:|----------------------------------:|---------------------------------------:|-----------------------------------:|
| variable_alpha_stress |    1.900000 | 40.000000 | 0.250000 |             0.761505 |             0.896367 |              0.803512 |               0.761507 |          0.081139 |            29.500000 |           0.073738 |              0.820000 |                     0.002011 |                     0.024789 |               0.083762 |                 28.500000 |                0.070464 |                          0.002623 |                               1.000000 |                           0.003275 |             0.760000 |                    0.005983 |                         0.000106 |                              3.500000 |                          0.003652 |              0.800000 |                     0.002735 |                          0.001712 |                               0.500000 |                           0.000361 |

## N=500 scaling and susceptibility heterogeneity

| case                        |   n_nodes |   susceptibility_sigma |   susceptibility_min |   susceptibility_max |   contact_spectral_radius |   threshold_spectral_radius |   rho_qw_over_rho_w |   critical_beta |   subcritical_final_I |   supercritical_final_I |
|:----------------------------|----------:|-----------------------:|---------------------:|---------------------:|--------------------------:|----------------------------:|--------------------:|----------------:|----------------------:|------------------------:|
| N500_baseline_heterogeneity |       500 |               0.230000 |             0.580000 |             1.750000 |                  1.392104 |                    1.420650 |            1.020506 |        0.211171 |              0.000372 |                0.007426 |
| N500_strong_heterogeneity   |       500 |               0.600000 |             0.350000 |             3.000000 |                  1.392104 |                    1.612815 |            1.158545 |        0.186010 |              0.000362 |                0.006902 |

## Numerical preservation diagnostics

- Minimum state over all runs: 0.000e+00.
- Maximum node-wise |S+I+R-1| over all runs: 3.997e-15.
